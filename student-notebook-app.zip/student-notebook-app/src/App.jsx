import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Pen, Eraser, Highlighter, Trash2, Plus, BookOpen, CalendarClock, Calendar as CalendarIcon,
  Link2, Upload, Check, X, ChevronRight, ChevronLeft, AlertCircle, Type, ArrowLeft,
  ExternalLink, FileText, Loader2, GripVertical, Pencil, Image as ImageIcon, Undo2, StickyNote, Maximize2, Star, Square, Circle, Triangle, Minus, Shapes, ArrowUpRight, Clock, Timer,
} from 'lucide-react';

// ---------- Design tokens: white + pink chrome, pastel pages, bold Helvetica ----------
const FONT = "'Helvetica Neue', Helvetica, Arial, sans-serif";

const COLORS = {
  paper: '#FFFFFF',
  paperTint: '#FFF4F8',
  paperLine: '#F0E4EA',
  ink: '#18181B',
  inkSoft: '#55555C',
  pink: '#FF3E7F',
  pinkDeep: '#C2185B',
  pinkSoft: '#FFE1EC',
  graphite: '#9A9AA2',
  red: '#E0245E',
  yellow: '#F2A93B',
  green: '#3FA796',
  spine: '#FFFFFF',
};

const PEN_COLORS = [
  { name: 'Black', value: '#18181B' },
  { name: 'Blue', value: '#2563EB' },
  { name: 'Pink', value: '#FF3E7F' },
  { name: 'Red', value: '#E0245E' },
  { name: 'Purple', value: '#7C3AED' },
];

const PEN_THICKNESSES = [
  { name: 'Thin', value: 0.6, dot: 4 },
  { name: 'Medium', value: 1, dot: 6 },
  { name: 'Thick', value: 1.6, dot: 8 },
  { name: 'Bold', value: 2.4, dot: 10 },
];

const HIGHLIGHT_COLORS = [
  { name: 'Yellow', value: '#FFEB3B' },
  { name: 'Green', value: '#76FF03' },
  { name: 'Pink', value: '#FF4FA0' },
  { name: 'Blue', value: '#40C4FF' },
  { name: 'Orange', value: '#FFAB40' },
];

const STICKY_COLORS = [
  { name: 'Yellow', value: '#FFF176' },
  { name: 'Pink', value: '#FFB3C6' },
  { name: 'Blue', value: '#AEE2FF' },
  { name: 'Green', value: '#B9F2D1' },
];

const SHAPE_TYPES = [
  { id: 'rectangle', label: 'Rectangle', icon: 'square' },
  { id: 'ellipse', label: 'Circle', icon: 'circle' },
  { id: 'triangle', label: 'Triangle', icon: 'triangle' },
  { id: 'line', label: 'Line', icon: 'line' },
];

const FILL_MODES = [
  { id: 'solid', label: 'Solid' },
  { id: 'semi', label: 'Semi' },
  { id: 'outline', label: 'Outline' },
];

const COVER_COLORS = ['#FF3E7F', '#C2185B', '#18181B', '#FFC46B', '#8FD3C9', '#B8C6FB', '#F4A6C6', '#6B7280'];

const COVER_DESIGNS = [
  { id: 'solid', label: 'Solid' },
  { id: 'dots', label: 'Dots' },
  { id: 'stripe', label: 'Stripe' },
  { id: 'arc', label: 'Arc' },
];

// Pastel variety for the pages themselves — kept neutral so pink stays the app's accent, not the writing surface.
const PAGE_BG_COLORS = [
  { name: 'White', value: '#FFFFFF' },
  { name: 'Cream', value: '#FFF9EE' },
  { name: 'Mint', value: '#E9F6EF' },
  { name: 'Sky', value: '#E8F2FB' },
  { name: 'Lavender', value: '#F1EBFB' },
  { name: 'Peach', value: '#FFF1E6' },
  { name: 'Butter', value: '#FFF8D8' },
  { name: 'Blush', value: '#FDECF2' },
];

const PAGE_TYPES = ['blank', 'ruled', 'grid', 'dot'];
const RULE_LINE_HEIGHT = 32;

const NOTEBOOK_TABS = [
  { id: 'library', label: 'Library' },
  { id: 'planner', label: 'Planner' },
  { id: 'calendar', label: 'Calendar' },
];

const PDFJS_VERSION = '3.11.174';

// ---------- Storage helpers ----------
async function storageGet(key, fallback) {
  try {
    const res = await window.storage.get(key, false);
    return res ? JSON.parse(res.value) : fallback;
  } catch (e) {
    return fallback;
  }
}
// Retries a few times with short delays — a safety net for reads that happen
// right after a write, in case storage takes a moment to catch up.
async function storageGetWithRetry(key, fallback, attempts = 4, delayMs = 200) {
  for (let i = 0; i < attempts; i++) {
    const val = await storageGet(key, undefined);
    if (val !== undefined) return val;
    if (i < attempts - 1) await new Promise((r) => setTimeout(r, delayMs));
  }
  return fallback;
}
async function storageSet(key, value) {
  try {
    const result = await window.storage.set(key, JSON.stringify(value), false);
    return result ? result : null;
  } catch (e) {
    console.error('storage set failed', e);
    return null;
  }
}

// ---------- PDF.js dynamic loader ----------
let pdfjsLoadPromise = null;
function loadPdfJs() {
  if (typeof window !== 'undefined' && window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
  if (pdfjsLoadPromise) return pdfjsLoadPromise;
  pdfjsLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.min.js`;
    script.onload = () => {
      if (!window.pdfjsLib) {
        pdfjsLoadPromise = null;
        reject(new Error('PDF renderer script loaded but pdfjsLib was not defined'));
        return;
      }
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.worker.min.js`;
      resolve(window.pdfjsLib);
    };
    script.onerror = () => {
      pdfjsLoadPromise = null;
      reject(new Error('Failed to load PDF renderer'));
    };
    document.head.appendChild(script);
  });
  return pdfjsLoadPromise;
}

// ---------- Raw PDF file storage (chunked base64) ----------
// Instead of pre-rendering every page to an image and storing dozens of
// separate shards (fragile — lots of writes/reads that can race each other),
// we store the original PDF file itself, in a few large chunks, and render
// pages live from it on demand — the same approach real PDF readers use.
const FILE_CHUNK_SIZE = 3_000_000; // base64 characters per chunk

function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
function base64ToArrayBuffer(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function storePdfSourceFile(notebookId, arrayBuffer) {
  const base64 = arrayBufferToBase64(arrayBuffer);
  const chunkCount = Math.ceil(base64.length / FILE_CHUNK_SIZE) || 1;
  for (let i = 0; i < chunkCount; i++) {
    const chunk = base64.slice(i * FILE_CHUNK_SIZE, (i + 1) * FILE_CHUNK_SIZE);
    await storageSet(`note-pdf-src:${notebookId}:${i}`, chunk);
  }
  await storageSet(`note-pdf-src-meta:${notebookId}`, { chunkCount });
}

async function loadPdfSourceFile(notebookId) {
  const meta = await storageGetWithRetry(`note-pdf-src-meta:${notebookId}`, null, 6, 250);
  if (!meta) return null;
  let base64 = '';
  for (let i = 0; i < meta.chunkCount; i++) {
    const chunk = await storageGetWithRetry(`note-pdf-src:${notebookId}:${i}`, null, 6, 250);
    if (chunk === null) return null;
    base64 += chunk;
  }
  return base64ToArrayBuffer(base64);
}

// Cache the parsed pdf.js document per notebook so switching between pages
// within the same notebook doesn't re-parse the whole file each time.
const pdfDocCache = new Map();
async function loadPdfDocument(notebookId) {
  if (pdfDocCache.has(notebookId)) return pdfDocCache.get(notebookId);
  const buf = await loadPdfSourceFile(notebookId);
  if (!buf) return null;
  const pdfjsLib = await loadPdfJs();
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  pdfDocCache.set(notebookId, pdf);
  return pdf;
}

// ---------- ICS parsing ----------
function unfoldICS(text) {
  return text.replace(/\r\n[ \t]/g, '').replace(/\n[ \t]/g, '');
}
function parseICSDate(raw) {
  if (!raw) return null;
  const clean = raw.replace('Z', '');
  const m = clean.match(/^(\d{4})(\d{2})(\d{2})(T(\d{2})(\d{2})(\d{2}))?$/);
  if (!m) return null;
  const [, y, mo, d, , h = '0', mi = '0'] = m;
  return new Date(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi));
}
function parseICS(text) {
  const unfolded = unfoldICS(text);
  const blocks = unfolded.split('BEGIN:VEVENT').slice(1);
  const events = [];
  for (const block of blocks) {
    const body = block.split('END:VEVENT')[0];
    const getField = (name) => {
      const re = new RegExp(name + '(;[^:]*)?:(.*)');
      const m = body.match(re);
      return m ? m[2].trim() : null;
    };
    const summary = getField('SUMMARY');
    const dtstart = getField('DTSTART');
    const uid = getField('UID') || `${summary}-${dtstart}-${Math.random()}`;
    const description = getField('DESCRIPTION');
    if (summary) {
      events.push({
        id: uid,
        title: summary.replace(/\\,/g, ',').replace(/\\n/g, ' '),
        due: parseICSDate(dtstart)?.toISOString() || null,
        notes: description ? description.replace(/\\n/g, ' ').slice(0, 200) : '',
        done: false,
        source: 'moodle',
      });
    }
  }
  return events;
}

const DURATION_OPTIONS = [
  { value: 0.5, label: '30 min' },
  { value: 1, label: '1 hr' },
  { value: 2, label: '2 hr' },
];

function dueStatus(assignment) {
  if (!assignment) return { label: 'No date', color: COLORS.graphite };
  if (assignment.done) return { label: 'Done', color: COLORS.green };
  const dueISO = assignment.due;
  if (!dueISO) return { label: 'No date', color: COLORS.graphite };
  const due = new Date(dueISO);
  const now = new Date();
  const diffHours = (due - now) / (1000 * 60 * 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < -3) return { label: 'Super Late', color: COLORS.red };
  if (diffHours < 0) return { label: 'Late', color: COLORS.red };
  const duration = assignment.duration || 1;
  // The less time remaining relative to how long the task takes, the more urgent it is.
  if (diffHours <= duration * 3) return { label: 'Urgent', color: '#F0632E' };
  if (diffDays === 0) return { label: 'Due today', color: COLORS.pink };
  if (diffDays <= 3) return { label: `Due in ${diffDays}d`, color: COLORS.yellow };
  return { label: due.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), color: COLORS.green };
}

function formatDueTime(timeStr) {
  if (!timeStr) return '';
  const [h, m] = timeStr.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m);
  return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

function localDateInputValue(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function localTimeInputValue(d = new Date()) {
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function dateKey(d) {
  const dt = new Date(d);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

function getPageStyle(pageType, bgColor) {
  const lineColor = 'rgba(24,24,27,0.10)';
  switch (pageType) {
    case 'ruled':
      return { backgroundColor: bgColor, backgroundImage: `repeating-linear-gradient(${bgColor}, ${bgColor} 31px, ${lineColor} 32px)` };
    case 'grid':
      return {
        backgroundColor: bgColor,
        backgroundImage: `linear-gradient(${lineColor} 1px, transparent 1px), linear-gradient(90deg, ${lineColor} 1px, transparent 1px)`,
        backgroundSize: '24px 24px',
      };
    case 'dot':
      return { backgroundColor: bgColor, backgroundImage: `radial-gradient(${lineColor} 1.4px, transparent 1.4px)`, backgroundSize: '20px 20px' };
    case 'pdf':
      return { backgroundColor: '#FFFFFF' };
    default:
      return { backgroundColor: bgColor };
  }
}

// Basic cover "designs" — a subtle geometric layer on top of the chosen color.
function getCoverStyle(design, color) {
  switch (design) {
    case 'dots':
      return { backgroundColor: color, backgroundImage: 'radial-gradient(rgba(255,255,255,0.4) 2px, transparent 2px)', backgroundSize: '14px 14px' };
    case 'stripe':
      return { backgroundColor: color, backgroundImage: 'repeating-linear-gradient(45deg, rgba(255,255,255,0.28) 0px, rgba(255,255,255,0.28) 6px, transparent 6px, transparent 16px)' };
    case 'arc':
      return { backgroundColor: color, backgroundImage: 'radial-gradient(circle at 100% 100%, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.4) 38%, transparent 39%)' };
    default:
      return { backgroundColor: color };
  }
}

// Small live preview of a page layout — shows the actual line/dot/grid pattern, not just a label.
function PageTypePreview({ pageType, bgColor, selected, onClick, label }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1" style={{ background: 'transparent', border: 'none', padding: 0 }}>
      <div
        className="rounded-md overflow-hidden"
        style={{ ...getPageStyle(pageType, bgColor || '#FFFFFF'), width: 44, height: 56, border: `2px solid ${selected ? COLORS.pink : COLORS.paperLine}`, backgroundSize: pageType === 'grid' ? '8px 8px' : pageType === 'dot' ? '7px 7px' : undefined, backgroundImage: pageType === 'ruled' ? getPageStyle(pageType, bgColor || '#FFFFFF').backgroundImage?.replace('31px', '9px').replace('32px', '10px') : getPageStyle(pageType, bgColor || '#FFFFFF').backgroundImage }}
      />
      {label && <span className="text-xs capitalize" style={{ color: selected ? COLORS.pink : COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>{label}</span>}
    </button>
  );
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ---------- Link/embed parsing ----------
function getEmbedInfo(rawUrl) {
  let url = rawUrl.trim();
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
  try {
    const u = new URL(url);
    const host = u.hostname.replace('www.', '');
    if (host === 'youtube.com' || host === 'm.youtube.com') {
      const id = u.searchParams.get('v') || u.pathname.split('/').filter(Boolean).pop();
      if (id) return { type: 'youtube', embedUrl: `https://www.youtube.com/embed/${id}`, host, original: url };
    }
    if (host === 'youtu.be') {
      const id = u.pathname.slice(1);
      return { type: 'youtube', embedUrl: `https://www.youtube.com/embed/${id}`, host, original: url };
    }
    if (host === 'vimeo.com') {
      const id = u.pathname.split('/').filter(Boolean).pop();
      return { type: 'vimeo', embedUrl: `https://player.vimeo.com/video/${id}`, host, original: url };
    }
    if (u.pathname.toLowerCase().endsWith('.pdf')) {
      return { type: 'pdf', embedUrl: url, host, original: url };
    }
    return { type: 'link', embedUrl: url, host, original: url };
  } catch (e) {
    return { type: 'link', embedUrl: url, host: url, original: url };
  }
}

const EMBED_DEFAULT_SIZE = {
  youtube: { width: 300, height: 180 },
  vimeo: { width: 300, height: 180 },
  pdf: { width: 280, height: 360 },
  link: { width: 260, height: 76 },
};

// ---------- Overlay layer: typed text + link/pdf/video embeds ----------
function OverlayLayer({ pageId, tool, stickyColor, shapeType, fillMode, shapeColor, arrowColor, onConsumeTool }) {
  const [boxes, setBoxes] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [pendingUrlId, setPendingUrlId] = useState(null);
  const [urlDraft, setUrlDraft] = useState('');
  const [draftArrow, setDraftArrow] = useState(null);
  const [selectedBoxId, setSelectedBoxId] = useState(null);
  const dragState = useRef(null);
  const resizeState = useRef(null);
  const containerRef = useRef(null);
  const [ready, setReady] = useState(false);
  // Strict exclusivity: this whole layer (and everything in it) only ever
  // accepts touches while one of its own tools is selected — drawing tools
  // get the canvas entirely to themselves, with no exceptions.
  const overlayActive = tool === 'text' || tool === 'link' || tool === 'sticky' || tool === 'shape' || tool === 'arrow';
  const boxPointerEvents = overlayActive ? 'auto' : 'none';

  useEffect(() => {
    (async () => {
      const saved = await storageGet(`note-overlay:${pageId}`, []);
      setBoxes(saved);
      setReady(true);
    })();
  }, [pageId]);

  useEffect(() => {
    setSelectedBoxId(null);
  }, [tool]);

  const persist = async (updated) => {
    setBoxes(updated);
    await storageSet(`note-overlay:${pageId}`, updated);
  };

  const handleContainerPointerDown = (e) => {
    if (tool !== 'text' && tool !== 'link' && tool !== 'sticky' && tool !== 'shape' && tool !== 'arrow') return;
    if (e.target !== containerRef.current) return;
    setSelectedBoxId(null);
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = `box-${Date.now()}`;
    if (tool === 'text') {
      const snappedY = Math.round(y / RULE_LINE_HEIGHT) * RULE_LINE_HEIGHT;
      const box = { id, kind: 'text', text: '', x, y: snappedY, fontSize: 20, lineHeight: RULE_LINE_HEIGHT, color: COLORS.ink, width: 320 };
      persist([...boxes, box]);
      setEditingId(id);
    } else if (tool === 'sticky') {
      const box = { id, kind: 'sticky', text: '', x, y, width: 140, height: 140, color: stickyColor || STICKY_COLORS[0].value };
      persist([...boxes, box]);
      setEditingId(id);
    } else if (tool === 'shape') {
      const isLine = shapeType === 'line';
      const box = { id, kind: 'shape', shapeType: shapeType || 'rectangle', fillMode: fillMode || 'solid', color: shapeColor || PEN_COLORS[0].value, x, y, width: isLine ? 140 : 120, height: isLine ? 90 : 120 };
      persist([...boxes, box]);
      setSelectedBoxId(id);
    } else if (tool === 'arrow') {
      startArrowDraw(x, y);
    } else {
      const box = { id, kind: 'embed', url: '', embedType: null, x, y, width: 280, height: 180 };
      setBoxes([...boxes, box]);
      setPendingUrlId(id);
      setUrlDraft('');
    }
    onConsumeTool?.();
  };

  const startArrowDraw = (x, y) => {
    const id = `arrow-${Date.now()}`;
    const startColor = arrowColor || PEN_COLORS[0].value;
    setDraftArrow({ id, x1: x, y1: y, x2: x, y2: y, color: startColor });
    const onMove = (ev) => {
      const r = containerRef.current.getBoundingClientRect();
      const nx = ev.clientX - r.left;
      const ny = ev.clientY - r.top;
      setDraftArrow((prev) => (prev ? { ...prev, x2: nx, y2: ny } : prev));
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      setDraftArrow((current) => {
        if (current) {
          const dist = Math.hypot(current.x2 - current.x1, current.y2 - current.y1);
          if (dist > 10) {
            const arrowBox = { id: current.id, kind: 'arrow', x1: current.x1, y1: current.y1, x2: current.x2, y2: current.y2, color: current.color };
            setBoxes((prevBoxes) => {
              const updated = [...prevBoxes, arrowBox];
              storageSet(`note-overlay:${pageId}`, updated);
              return updated;
            });
            setSelectedBoxId(arrowBox.id);
          }
        }
        return null;
      });
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startEndpointDrag = (e, arrowBox, which) => {
    e.stopPropagation();
    const onMove = (ev) => {
      const r = containerRef.current.getBoundingClientRect();
      const nx = ev.clientX - r.left;
      const ny = ev.clientY - r.top;
      setBoxes((prev) => prev.map((b) => (b.id === arrowBox.id ? { ...b, ...(which === 'start' ? { x1: nx, y1: ny } : { x2: nx, y2: ny }) } : b)));
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      setBoxes((prev) => { storageSet(`note-overlay:${pageId}`, prev); return prev; });
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startDrag = (e, box) => {
    if (editingId === box.id || pendingUrlId === box.id) return;
    e.stopPropagation();
    const rect = containerRef.current.getBoundingClientRect();
    dragState.current = { id: box.id, offsetX: e.clientX - rect.left - box.x, offsetY: e.clientY - rect.top - box.y };
    const onMove = (ev) => {
      if (!dragState.current) return;
      const r = containerRef.current.getBoundingClientRect();
      const nx = ev.clientX - r.left - dragState.current.offsetX;
      const ny = ev.clientY - r.top - dragState.current.offsetY;
      setBoxes((prev) => prev.map((b) => (b.id === dragState.current.id ? { ...b, x: nx, y: ny } : b)));
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      setBoxes((prev) => { storageSet(`note-overlay:${pageId}`, prev); return prev; });
      dragState.current = null;
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startResize = (e, box) => {
    e.stopPropagation();
    resizeState.current = { id: box.id, startX: e.clientX, startY: e.clientY, startW: box.width, startH: box.height };
    const onMove = (ev) => {
      if (!resizeState.current) return;
      const dx = ev.clientX - resizeState.current.startX;
      const dy = ev.clientY - resizeState.current.startY;
      const newW = Math.max(40, Math.min(700, resizeState.current.startW + dx));
      const newH = Math.max(40, Math.min(700, resizeState.current.startH + dy));
      setBoxes((prev) => prev.map((b) => (b.id === resizeState.current.id ? { ...b, width: newW, height: newH } : b)));
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      setBoxes((prev) => { storageSet(`note-overlay:${pageId}`, prev); return prev; });
      resizeState.current = null;
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const updateText = (id, text) => setBoxes((prev) => prev.map((b) => (b.id === id ? { ...b, text } : b)));

  const finishTextEdit = (id) => {
    setEditingId(null);
    setBoxes((prev) => {
      const cleaned = prev.filter((b) => b.id !== id || b.text.trim() !== '');
      storageSet(`note-overlay:${pageId}`, cleaned);
      return cleaned;
    });
  };

  const submitUrl = (id) => {
    if (!urlDraft.trim()) {
      const cleaned = boxes.filter((b) => b.id !== id);
      persist(cleaned);
      setPendingUrlId(null);
      return;
    }
    const info = getEmbedInfo(urlDraft);
    const size = EMBED_DEFAULT_SIZE[info.type];
    const updated = boxes.map((b) => (b.id === id ? { ...b, url: info.original, embedType: info.type, host: info.host, embedUrl: info.embedUrl, width: size.width, height: size.height } : b));
    persist(updated);
    setPendingUrlId(null);
    setUrlDraft('');
  };

  const deleteBox = (id) => persist(boxes.filter((b) => b.id !== id));

  if (!ready) return null;

  return (
    <div
      ref={containerRef}
      onPointerDown={handleContainerPointerDown}
      className="absolute inset-0"
      style={{ cursor: tool === 'text' ? 'text' : tool === 'arrow' ? 'crosshair' : tool === 'link' || tool === 'sticky' || tool === 'shape' ? 'copy' : 'default', pointerEvents: overlayActive ? 'auto' : 'none' }}
    >
      {boxes.map((box) => {
        if (box.kind === 'text') {
          return (
            <div key={box.id} className="absolute group" style={{ left: box.x, top: box.y, width: box.width, pointerEvents: boxPointerEvents }}>
              {editingId === box.id ? (
                <textarea
                  autoFocus
                  value={box.text}
                  onChange={(e) => updateText(box.id, e.target.value)}
                  onBlur={() => finishTextEdit(box.id)}
                  rows={2}
                  className="w-full resize-none outline-none bg-transparent"
                  style={{ fontSize: box.fontSize, lineHeight: `${box.lineHeight || RULE_LINE_HEIGHT}px`, color: box.color, fontFamily: FONT, fontWeight: 600, border: `1px dashed ${COLORS.pink}`, borderRadius: 4, padding: 2 }}
                />
              ) : (
                <div className="relative">
                  <div onPointerDown={(e) => startDrag(e, box)} onDoubleClick={() => setEditingId(box.id)} className="whitespace-pre-wrap cursor-move" style={{ fontSize: box.fontSize, lineHeight: `${box.lineHeight || RULE_LINE_HEIGHT}px`, color: box.color, fontFamily: FONT, fontWeight: 600, minHeight: 20 }}>
                    {box.text || <span style={{ color: COLORS.graphite }}>Empty text</span>}
                  </div>
                  <button onClick={() => deleteBox(box.id)} className="absolute -top-2 -right-2 w-4 h-4 rounded-full items-center justify-center opacity-0 group-hover:opacity-100 hidden group-hover:flex" style={{ background: COLORS.pink, color: '#fff' }}>
                    <X size={10} />
                  </button>
                </div>
              )}
            </div>
          );
        }
        if (box.kind === 'sticky') {
          return (
            <div
              key={box.id}
              className="absolute group flex flex-col rounded-sm shadow-md"
              style={{ left: box.x, top: box.y, width: box.width, height: box.height, background: box.color, pointerEvents: boxPointerEvents, boxShadow: '0 3px 10px rgba(0,0,0,0.18)' }}
            >
              <div onPointerDown={(e) => startDrag(e, box)} className="flex items-center justify-end px-1.5 pt-1.5 cursor-move shrink-0">
                <button onPointerDown={(e) => e.stopPropagation()} onClick={() => deleteBox(box.id)} className="opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: 'rgba(0,0,0,0.5)' }}>
                  <X size={12} />
                </button>
              </div>
              {editingId === box.id ? (
                <textarea
                  autoFocus
                  value={box.text}
                  onChange={(e) => updateText(box.id, e.target.value)}
                  onBlur={() => finishTextEdit(box.id)}
                  className="flex-1 w-full resize-none outline-none bg-transparent px-2 pb-2"
                  style={{ fontSize: 14, color: COLORS.ink, fontFamily: FONT, fontWeight: 600 }}
                />
              ) : (
                <div onDoubleClick={() => setEditingId(box.id)} className="flex-1 px-2 pb-2 overflow-hidden whitespace-pre-wrap" style={{ fontSize: 14, color: COLORS.ink, fontFamily: FONT, fontWeight: 600 }}>
                  {box.text || <span style={{ color: 'rgba(0,0,0,0.4)' }}>Tap to write…</span>}
                </div>
              )}
              <div
                onPointerDown={(e) => startResize(e, box)}
                className="absolute flex items-center justify-center rounded-full"
                style={{ right: -4, bottom: -4, width: 26, height: 26, cursor: 'nwse-resize', background: 'rgba(255,255,255,0.85)', border: `1px solid ${COLORS.paperLine}` }}
              >
                <Maximize2 size={12} style={{ transform: 'rotate(90deg)', color: 'rgba(0,0,0,0.5)' }} />
              </div>
            </div>
          );
        }
        if (box.kind === 'shape') {
          const fillProps = box.fillMode === 'outline'
            ? { fill: 'none', stroke: box.color, strokeWidth: 4 }
            : box.fillMode === 'semi'
            ? { fill: box.color, fillOpacity: 0.35, stroke: 'none' }
            : { fill: box.color, stroke: 'none' };
          const isSelected = selectedBoxId === box.id;
          return (
            <div
              key={box.id}
              onPointerDown={(e) => { setSelectedBoxId(box.id); startDrag(e, box); }}
              className="absolute cursor-move"
              style={{ left: box.x, top: box.y, width: box.width, height: box.height, pointerEvents: boxPointerEvents, outline: isSelected ? `2px dashed ${COLORS.pink}` : 'none', outlineOffset: 2 }}
            >
              <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
                {box.shapeType === 'rectangle' && <rect x="3" y="3" width="94" height="94" rx="6" {...fillProps} />}
                {box.shapeType === 'ellipse' && <ellipse cx="50" cy="50" rx="47" ry="47" {...fillProps} />}
                {box.shapeType === 'triangle' && <polygon points="50,4 96,96 4,96" {...fillProps} />}
                {box.shapeType === 'line' && <line x1="6" y1="94" x2="94" y2="6" stroke={box.color} strokeWidth="6" strokeLinecap="round" />}
              </svg>
              {isSelected && (
                <>
                  <button onPointerDown={(e) => e.stopPropagation()} onClick={() => deleteBox(box.id)} className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center" style={{ background: COLORS.pink, color: '#fff' }}>
                    <X size={10} />
                  </button>
                  <div
                    onPointerDown={(e) => { e.stopPropagation(); startResize(e, box); }}
                    className="absolute flex items-center justify-center rounded-full"
                    style={{ right: -6, bottom: -6, width: 26, height: 26, cursor: 'nwse-resize', background: 'rgba(255,255,255,0.9)', border: `1px solid ${COLORS.paperLine}` }}
                  >
                    <Maximize2 size={12} style={{ transform: 'rotate(90deg)', color: COLORS.graphite }} />
                  </div>
                </>
              )}
            </div>
          );
        }
        if (box.kind === 'arrow') {
          const left = Math.min(box.x1, box.x2);
          const top = Math.min(box.y1, box.y2);
          const w = Math.max(Math.abs(box.x2 - box.x1), 1);
          const h = Math.max(Math.abs(box.y2 - box.y1), 1);
          const dx = box.x2 - box.x1;
          const dy = box.y2 - box.y1;
          const angle = (Math.atan2(dy, dx) * 180) / Math.PI;
          const length = Math.max(Math.hypot(dx, dy) - 9, 4);
          const isSelected = selectedBoxId === box.id;
          return (
            <div key={box.id} className="absolute" style={{ left, top, width: w, height: h, overflow: 'visible', pointerEvents: 'none' }}>
              <div style={{ position: 'absolute', left: box.x1 - left, top: box.y1 - top, width: length, height: 3, background: box.color, transformOrigin: '0 50%', transform: `rotate(${angle}deg)`, borderRadius: 2 }} />
              <div style={{ position: 'absolute', left: box.x2 - left - 9, top: box.y2 - top - 6, transform: `rotate(${angle}deg)` }}>
                <svg width="12" height="12" viewBox="0 0 12 12"><polygon points="0,0 12,6 0,12" fill={box.color} /></svg>
              </div>
              {/* wide invisible hit-area along the shaft so tapping the arrow selects it */}
              <div
                onPointerDown={(e) => { e.stopPropagation(); setSelectedBoxId(box.id); }}
                className="absolute"
                style={{ left: box.x1 - left, top: box.y1 - top - 10, width: length, height: 20, transformOrigin: '0 50%', transform: `rotate(${angle}deg)`, pointerEvents: boxPointerEvents, cursor: 'pointer' }}
              />
              {isSelected && (
                <>
                  <div
                    onPointerDown={(e) => startEndpointDrag(e, box, 'start')}
                    className="absolute rounded-full"
                    style={{ left: box.x1 - left - 7, top: box.y1 - top - 7, width: 14, height: 14, background: '#fff', border: `2px solid ${box.color}`, pointerEvents: boxPointerEvents, cursor: 'grab' }}
                  />
                  <div
                    onPointerDown={(e) => startEndpointDrag(e, box, 'end')}
                    className="absolute rounded-full"
                    style={{ left: box.x2 - left - 7, top: box.y2 - top - 7, width: 14, height: 14, background: '#fff', border: `2px solid ${box.color}`, pointerEvents: boxPointerEvents, cursor: 'grab' }}
                  />
                  <button
                    onClick={() => deleteBox(box.id)}
                    className="absolute w-5 h-5 rounded-full flex items-center justify-center"
                    style={{ left: (box.x1 + box.x2) / 2 - left - 10, top: (box.y1 + box.y2) / 2 - top - 18, background: COLORS.pink, color: '#fff', pointerEvents: boxPointerEvents }}
                  >
                    <X size={10} />
                  </button>
                </>
              )}
            </div>
          );
        }
        const awaitingUrl = pendingUrlId === box.id;
        return (
          <div key={box.id} className="absolute group rounded-lg overflow-hidden shadow-sm" style={{ left: box.x, top: box.y, width: box.width, pointerEvents: boxPointerEvents, background: '#fff', border: `1px solid ${COLORS.paperLine}` }}>
            <div onPointerDown={(e) => startDrag(e, box)} className="flex items-center gap-1.5 px-2 py-1.5 cursor-move" style={{ background: COLORS.ink }}>
              <GripVertical size={12} color="#fff" />
              <span className="text-xs flex-1 truncate text-white" style={{ fontFamily: FONT, fontWeight: 700 }}>{box.host || 'add a link'}</span>
              {box.url && (
                <a href={box.url} target="_blank" rel="noopener noreferrer" onPointerDown={(e) => e.stopPropagation()} title="Open externally">
                  <ExternalLink size={12} color="#fff" />
                </a>
              )}
              <button onPointerDown={(e) => e.stopPropagation()} onClick={() => deleteBox(box.id)} title="Remove">
                <X size={12} color="#fff" />
              </button>
            </div>

            {awaitingUrl ? (
              <div className="p-2">
                <input
                  autoFocus
                  value={urlDraft}
                  onChange={(e) => setUrlDraft(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && submitUrl(box.id)}
                  placeholder="Paste a YouTube, Vimeo, or PDF link"
                  className="w-full px-2 py-1.5 text-xs rounded border outline-none mb-1.5"
                  style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }}
                />
                <button onClick={() => submitUrl(box.id)} className="w-full py-1.5 rounded text-xs" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Embed</button>
              </div>
            ) : box.embedType === 'youtube' || box.embedType === 'vimeo' ? (
              <div style={{ height: box.height }}>
                <iframe src={box.embedUrl} width="100%" height="100%" frameBorder="0" allow="autoplay; encrypted-media; fullscreen" allowFullScreen title="video embed" />
              </div>
            ) : box.embedType === 'pdf' ? (
              <div style={{ height: box.height }} className="flex flex-col">
                <iframe src={box.embedUrl} width="100%" height="100%" frameBorder="0" title="pdf embed" />
                <a href={box.url} target="_blank" rel="noopener noreferrer" className="text-xs text-center py-1 border-t" style={{ color: COLORS.graphite, borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }}>
                  Not loading? Open PDF externally
                </a>
              </div>
            ) : (
              <a href={box.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-3 py-3">
                <Link2 size={16} color={COLORS.pink} />
                <span className="text-xs truncate" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 600 }}>{box.host}</span>
              </a>
            )}
          </div>
        );
      })}
      {draftArrow && (() => {
        const dx = draftArrow.x2 - draftArrow.x1;
        const dy = draftArrow.y2 - draftArrow.y1;
        const angle = (Math.atan2(dy, dx) * 180) / Math.PI;
        const length = Math.max(Math.hypot(dx, dy) - 9, 4);
        return (
          <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
            <div style={{ position: 'absolute', left: draftArrow.x1, top: draftArrow.y1, width: length, height: 3, background: draftArrow.color, transformOrigin: '0 50%', transform: `rotate(${angle}deg)`, borderRadius: 2, opacity: 0.75 }} />
            <div style={{ position: 'absolute', left: draftArrow.x2 - 9, top: draftArrow.y2 - 6, transform: `rotate(${angle}deg)`, opacity: 0.75 }}>
              <svg width="12" height="12" viewBox="0 0 12 12"><polygon points="0,0 12,6 0,12" fill={draftArrow.color} /></svg>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

// ---------- Drawing Canvas ----------
function DrawingCanvas({ pageId, pageMeta, pdfDoc, pdfLoadError }) {
  const wrapRef = useRef(null);
  const zoomLayerRef = useRef(null);
  const canvasRef = useRef(null);
  const highlightCanvasRef = useRef(null);
  const highlightCtxRef = useRef(null);
  const pdfCanvasRef = useRef(null);
  const ctxRef = useRef(null);
  const drawing = useRef(false);
  const [pencilUsed, setPencilUsed] = useState(false);
  const strokeStarted = useRef(false);
  const lastPoint = useRef(null);
  const lastMid = useRef(null);
  const pointBuffer = useRef([]);
  const penActive = useRef(false);
  const penGraceTimer = useRef(null);
  const lastWidth = useRef(null);
  const pinchState = useRef(null);

  const [zoom, setZoom] = useState(1);
  const clampZoom = (z) => Math.min(4, Math.max(1, z));

  const [color, setColor] = useState(PEN_COLORS[0].value);
  const [thickness, setThickness] = useState(PEN_THICKNESSES[1].value);
  const [hlColor, setHlColor] = useState(HIGHLIGHT_COLORS[0].value);
  const [stickyColor, setStickyColor] = useState(STICKY_COLORS[0].value);
  const [shapeType, setShapeType] = useState('rectangle');
  const [fillMode, setFillMode] = useState('solid');
  const [shapeColor, setShapeColor] = useState(PEN_COLORS[0].value);
  const [arrowColor, setArrowColor] = useState(PEN_COLORS[0].value);
  const [tool, setTool] = useState('pen');
  const [loaded, setLoaded] = useState(false);
  const [pdfRenderState, setPdfRenderState] = useState(null); // null | 'rendering' | 'found' | 'missing'
  const [history, setHistory] = useState([]);

  // ---- Canvas sizing: measured off the wrapper div (not the canvas itself),
  // and preserves whatever is currently drawn across a resize. ----
  const sizeCanvasToWrapper = useCallback(() => {
    const canvas = canvasRef.current;
    const hlCanvas = highlightCanvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !hlCanvas || !wrap) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = wrap.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;
    const prevData = canvas.width > 0 ? canvas.toDataURL('image/png') : null;
    const prevHlData = hlCanvas.width > 0 ? hlCanvas.toDataURL('image/png') : null;

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctxRef.current = ctx;

    hlCanvas.width = rect.width * dpr;
    hlCanvas.height = rect.height * dpr;
    hlCanvas.style.width = rect.width + 'px';
    hlCanvas.style.height = rect.height + 'px';
    const hlCtx = hlCanvas.getContext('2d');
    hlCtx.scale(dpr, dpr);
    hlCtx.lineCap = 'butt';
    hlCtx.lineJoin = 'miter';
    highlightCtxRef.current = hlCtx;

    if (prevData) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
      img.src = prevData;
    }
    if (prevHlData) {
      const img2 = new Image();
      img2.onload = () => hlCtx.drawImage(img2, 0, 0, rect.width, rect.height);
      img2.src = prevHlData;
    }
  }, []);

  const loadPage = useCallback(async () => {
    setLoaded(false);
    const [dataUrl, hlDataUrl] = await Promise.all([
      storageGet(`note-image:${pageId}`, null),
      storageGet(`note-highlight:${pageId}`, null),
    ]);
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    const hlCanvas = highlightCanvasRef.current;
    const hlCtx = highlightCtxRef.current;
    if (!canvas || !ctx) { setLoaded(true); return; }
    const dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
    if (hlCtx && hlCanvas) hlCtx.clearRect(0, 0, hlCanvas.width / dpr, hlCanvas.height / dpr);

    const loadOne = (url, targetCtx, targetCanvas) => new Promise((resolve) => {
      if (!url || !targetCtx || !targetCanvas) { resolve(); return; }
      const img = new Image();
      img.onload = () => { targetCtx.drawImage(img, 0, 0, targetCanvas.width / dpr, targetCanvas.height / dpr); resolve(); };
      img.onerror = () => resolve();
      img.src = url;
    });

    await Promise.all([
      loadOne(dataUrl, ctx, canvas),
      loadOne(hlDataUrl, hlCtx, hlCanvas),
    ]);
    setLoaded(true);
  }, [pageId]);

  const renderPdfPage = useCallback(async () => {
    if (!pageMeta.hasPdfBg) { setPdfRenderState(null); return; }
    if (!pdfDoc) { setPdfRenderState(pdfLoadError ? 'missing' : 'rendering'); return; }
    const canvas = pdfCanvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    try {
      setPdfRenderState('rendering');
      const page = await pdfDoc.getPage(pageMeta.pdfPageNumber || 1);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = wrap.getBoundingClientRect();
      canvas.width = Math.max(rect.width * dpr, 1);
      canvas.height = Math.max(rect.height * dpr, 1);
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const naturalViewport = page.getViewport({ scale: 1 });
      const fitScale = Math.min(canvas.width / naturalViewport.width, canvas.height / naturalViewport.height);
      const viewport = page.getViewport({ scale: fitScale });
      const offsetX = (canvas.width - viewport.width) / 2;
      const offsetY = (canvas.height - viewport.height) / 2;
      const offscreen = document.createElement('canvas');
      offscreen.width = viewport.width;
      offscreen.height = viewport.height;
      await page.render({ canvasContext: offscreen.getContext('2d'), viewport }).promise;
      ctx.drawImage(offscreen, offsetX, offsetY);
      offscreen.width = 0;
      offscreen.height = 0;
      setPdfRenderState('found');
    } catch (e) {
      console.error('PDF page render failed', e);
      setPdfRenderState('missing');
    }
  }, [pdfDoc, pageMeta.hasPdfBg, pageMeta.pdfPageNumber, pdfLoadError]);

  // Initial setup + whenever the page itself changes.
  useEffect(() => {
    sizeCanvasToWrapper();
    loadPage();
    setHistory([]);
    renderPdfPage();
  }, [pageId, pdfDoc, sizeCanvasToWrapper, loadPage, renderPdfPage]);

  // Resize handling kept separate: just resize/preserve, don't reload from storage.
  useEffect(() => {
    const onResize = () => { sizeCanvasToWrapper(); renderPdfPage(); };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [sizeCanvasToWrapper, renderPdfPage]);

  const savePage = async () => {
    const canvas = canvasRef.current;
    const hlCanvas = highlightCanvasRef.current;
    if (!canvas) return;
    await Promise.all([
      storageSet(`note-image:${pageId}`, canvas.toDataURL('image/png')),
      hlCanvas ? storageSet(`note-highlight:${pageId}`, hlCanvas.toDataURL('image/png')) : Promise.resolve(),
    ]);
  };

  const pushHistory = () => {
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    const hlCanvas = highlightCanvasRef.current;
    const hlCtx = highlightCtxRef.current;
    if (!canvas || !ctx) return;
    try {
      // Raw pixel snapshots instead of PNG data URLs — no encode/decode cost,
      // so taking them can't stall pointer tracking at the start of a stroke.
      const snapshot = {
        ink: ctx.getImageData(0, 0, canvas.width, canvas.height),
        highlight: hlCtx && hlCanvas ? hlCtx.getImageData(0, 0, hlCanvas.width, hlCanvas.height) : null,
      };
      setHistory((prev) => [...prev.slice(-19), snapshot]);
    } catch (e) {
      console.error('history snapshot failed', e);
    }
  };

  const undo = () => {
    if (history.length === 0) return;
    const ctx = ctxRef.current;
    const hlCtx = highlightCtxRef.current;
    if (!ctx) return;
    const prevSnapshot = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    ctx.putImageData(prevSnapshot.ink, 0, 0);
    if (hlCtx && prevSnapshot.highlight) hlCtx.putImageData(prevSnapshot.highlight, 0, 0);
    savePage();
  };

  const clearCanvas = () => {
    if (!window.confirm('Clear all ink and highlights on this page? This can be undone with the undo button, but not after you leave the page.')) return;
    pushHistory();
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    const hlCanvas = highlightCanvasRef.current;
    const hlCtx = highlightCtxRef.current;
    const dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
    if (hlCtx && hlCanvas) hlCtx.clearRect(0, 0, hlCanvas.width / dpr, hlCanvas.height / dpr);
    savePage();
  };

  // ---- Drawing itself: simple, direct pointer handling with midpoint
  // smoothing — deliberately minimal, mirroring the confirmed-working
  // standalone version rather than anything more elaborate. ----
  const getPos = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) / zoom,
      y: (e.clientY - rect.top) / zoom,
      pressure: e.pressure && e.pressure > 0 ? e.pressure : 0.5,
    };
  };

  const isDrawingTool = tool === 'pen' || tool === 'highlighter' || tool === 'eraser';

  // ---- Zoom: pinch with two fingers (combined with panning the same
  // gesture), or Ctrl/Cmd + scroll for trackpad/mouse users. ----
  const handleTouchStart = (e) => {
    if (e.touches.length === 2) {
      drawing.current = false;
      const [t1, t2] = e.touches;
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      pinchState.current = {
        startDist: dist,
        startZoom: zoom,
        startMidX: (t1.clientX + t2.clientX) / 2,
        startMidY: (t1.clientY + t2.clientY) / 2,
        startScrollLeft: wrapRef.current ? wrapRef.current.scrollLeft : 0,
        startScrollTop: wrapRef.current ? wrapRef.current.scrollTop : 0,
      };
    }
  };

  const handleTouchMove = (e) => {
    if (e.touches.length === 2 && pinchState.current) {
      e.preventDefault();
      const [t1, t2] = e.touches;
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const midX = (t1.clientX + t2.clientX) / 2;
      const midY = (t1.clientY + t2.clientY) / 2;
      const newZoom = clampZoom(pinchState.current.startZoom * (dist / pinchState.current.startDist));
      setZoom(newZoom);
      if (wrapRef.current) {
        wrapRef.current.scrollLeft = pinchState.current.startScrollLeft - (midX - pinchState.current.startMidX);
        wrapRef.current.scrollTop = pinchState.current.startScrollTop - (midY - pinchState.current.startMidY);
      }
    }
  };

  const handleTouchEnd = (e) => {
    if (e.touches.length < 2) pinchState.current = null;
  };

  const handleWheel = (e) => {
    if (!e.ctrlKey && !e.metaKey) return; // plain scroll stays as normal scroll/pan
    e.preventDefault();
    setZoom((z) => clampZoom(z - e.deltaY * 0.01));
  };

  const zoomStep = (delta) => setZoom((z) => clampZoom(Math.round((z + delta) * 100) / 100));
  const resetZoom = () => { setZoom(1); if (wrapRef.current) { wrapRef.current.scrollLeft = 0; wrapRef.current.scrollTop = 0; } };

  const handlePointerDown = (e) => {
    if (!isDrawingTool) return;
    e.preventDefault();
    if (e.pointerType === 'pen') {
      penActive.current = true;
      if (penGraceTimer.current) { clearTimeout(penGraceTimer.current); penGraceTimer.current = null; }
      if (!pencilUsed) setPencilUsed(true);
    }
    // Reject a finger touch only while the Pencil is actually in use (plus a
    // brief grace period after it lifts) — not permanently, so drawing with
    // a finger still works normally once the Pencil is set down.
    if (e.pointerType === 'touch' && penActive.current) return;
    canvasRef.current.setPointerCapture(e.pointerId);
    drawing.current = true;
    strokeStarted.current = false;
    lastWidth.current = null;
    const pos = getPos(e);
    pointBuffer.current = [pos];
    lastPoint.current = pos;
    lastMid.current = pos;
  };

  const drawSegment = (raw) => {
    const ctx = ctxRef.current;
    const hlCtx = highlightCtxRef.current;
    if (!ctx) return;

    // Average over the last few raw points before drawing anything — this
    // smooths out natural hand tremor and is the biggest factor in making
    // ink look calm and fluid instead of jagged, closer to GoodNotes.
    pointBuffer.current.push(raw);
    if (pointBuffer.current.length > 4) pointBuffer.current.shift();
    let sx = 0, sy = 0, wsum = 0;
    pointBuffer.current.forEach((p, i) => { const w = i + 1; sx += p.x * w; sy += p.y * w; wsum += w; });
    const pos = { x: sx / wsum, y: sy / wsum, pressure: raw.pressure };

    const prev = lastPoint.current;
    if (!prev) { lastPoint.current = pos; lastMid.current = pos; return; }

    if (tool === 'eraser') {
      // Curve through the midpoint of consecutive points — smooths a
      // jagged polyline into a flowing line — erasing both ink and any
      // highlight underneath, since that's what "erase" should mean here.
      const mid = { x: (prev.x + pos.x) / 2, y: (prev.y + pos.y) / 2 };
      const prevMid = lastMid.current || prev;
      [ctx, hlCtx].forEach((c) => {
        if (!c) return;
        c.beginPath();
        c.moveTo(prevMid.x, prevMid.y);
        c.quadraticCurveTo(prev.x, prev.y, mid.x, mid.y);
        c.globalAlpha = 1;
        c.globalCompositeOperation = 'destination-out';
        c.lineWidth = 24;
        c.stroke();
      });
      lastMid.current = mid;
      lastPoint.current = pos;
      return;
    }

    if (tool === 'highlighter') {
      // Drawn onto its own separate layer, always fully solid — the layer
      // itself is displayed at one fixed CSS opacity, so no matter how many
      // times you go back over the same spot, it can never get darker.
      // Straight segments with flat (butt) caps, like a real highlighter's
      // flat tip, instead of the curvy rounded strokes used for ink.
      if (hlCtx) {
        hlCtx.beginPath();
        hlCtx.moveTo(prev.x, prev.y);
        hlCtx.lineTo(pos.x, pos.y);
        hlCtx.globalAlpha = 1;
        hlCtx.globalCompositeOperation = 'source-over';
        hlCtx.lineWidth = 16;
        hlCtx.strokeStyle = hlColor;
        hlCtx.stroke();
      }
      lastMid.current = pos;
      lastPoint.current = pos;
      return;
    }

    // Pen: curve through the midpoint of consecutive points, using the
    // point itself as the control — smooths a jagged polyline into a
    // flowing line.
    const mid = { x: (prev.x + pos.x) / 2, y: (prev.y + pos.y) / 2 };
    const prevMid = lastMid.current || prev;
    ctx.beginPath();
    ctx.moveTo(prevMid.x, prevMid.y);
    ctx.quadraticCurveTo(prev.x, prev.y, mid.x, mid.y);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    // Smooth the width itself frame-to-frame too, so it tapers gradually
    // with pressure instead of jumping — closer to a real pen's feel.
    const targetWidth = (1.2 + pos.pressure * 3.2) * thickness;
    const prevWidth = lastWidth.current ?? targetWidth;
    const width = prevWidth + (targetWidth - prevWidth) * 0.4;
    lastWidth.current = width;
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.globalAlpha = 1;
    lastMid.current = mid;
    lastPoint.current = pos;
  };

  const handlePointerMove = (e) => {
    if (!drawing.current || !isDrawingTool) return;
    e.preventDefault();
    if (e.pointerType === 'touch' && penActive.current) return;
    if (!strokeStarted.current) { pushHistory(); strokeStarted.current = true; }
    // Coalesced events include every intermediate sample the browser
    // batched since the last event, not just the latest one — drawing all
    // of them (instead of only the most recent point) is what prevents fast
    // strokes from looking like they briefly "lost" the Pencil.
    const events = typeof e.getCoalescedEvents === 'function' ? e.getCoalescedEvents() : [];
    if (events.length > 0) {
      events.forEach((ev) => drawSegment(getPos(ev)));
    } else {
      drawSegment(getPos(e));
    }
  };

  const handlePointerUp = (e) => {
    if (e && e.pointerType === 'pen') {
      // Keep rejecting stray finger/palm contact for a short moment after
      // the Pencil lifts, then release the rejection so finger drawing
      // works normally again if the user picks up where they left off.
      if (penGraceTimer.current) clearTimeout(penGraceTimer.current);
      penGraceTimer.current = setTimeout(() => { penActive.current = false; }, 400);
    }
    if (!drawing.current) return;
    drawing.current = false;
    lastPoint.current = null;
    lastMid.current = null;
    pointBuffer.current = [];
    lastWidth.current = null;
    savePage();
  };

  const bgStyle = getPageStyle(pageMeta.pageType, pageMeta.bgColor);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b flex-wrap" style={{ borderColor: COLORS.paperLine, background: '#FFFFFF' }}>
        <span
          className="text-xs px-2 py-1 rounded-full shrink-0"
          style={{
            fontFamily: FONT, fontWeight: 800,
            background: isDrawingTool ? '#EAF7F3' : '#F1F4F8',
            color: isDrawingTool ? COLORS.green : COLORS.graphite,
            border: `1px solid ${isDrawingTool ? COLORS.green : COLORS.paperLine}`,
          }}
        >
          {isDrawingTool ? '● Drawing on' : '○ Drawing off'}
        </span>
        <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
        <button onClick={() => setTool('pen')} className="p-2 rounded-lg" style={{ background: tool === 'pen' ? COLORS.pink : 'transparent', color: tool === 'pen' ? '#fff' : COLORS.ink }} aria-label="Pen">
          <Pen size={16} />
        </button>
        <button onClick={() => setTool('highlighter')} className="p-2 rounded-lg" style={{ background: tool === 'highlighter' ? COLORS.pink : 'transparent', color: tool === 'highlighter' ? '#fff' : COLORS.ink }} aria-label="Highlighter">
          <Highlighter size={16} />
        </button>
        <button onClick={() => setTool('eraser')} className="p-2 rounded-lg" style={{ background: tool === 'eraser' ? COLORS.pink : 'transparent', color: tool === 'eraser' ? '#fff' : COLORS.ink }} aria-label="Eraser">
          <Eraser size={16} />
        </button>
        <button onClick={() => setTool('text')} className="p-2 rounded-lg" style={{ background: tool === 'text' ? COLORS.pink : 'transparent', color: tool === 'text' ? '#fff' : COLORS.ink }} aria-label="Type text">
          <Type size={16} />
        </button>
        <button onClick={() => setTool('link')} className="p-2 rounded-lg" style={{ background: tool === 'link' ? COLORS.pink : 'transparent', color: tool === 'link' ? '#fff' : COLORS.ink }} aria-label="Insert link">
          <Link2 size={16} />
        </button>
        <button onClick={() => setTool('sticky')} className="p-2 rounded-lg" style={{ background: tool === 'sticky' ? COLORS.pink : 'transparent', color: tool === 'sticky' ? '#fff' : COLORS.ink }} aria-label="Add sticky note">
          <StickyNote size={16} />
        </button>
        <button onClick={() => setTool((t) => (t === 'shape' ? 'pen' : 'shape'))} className="p-2 rounded-lg" style={{ background: tool === 'shape' ? COLORS.pink : 'transparent', color: tool === 'shape' ? '#fff' : COLORS.ink }} aria-label="Add shape">
          <Shapes size={16} />
        </button>
        <button onClick={() => setTool((t) => (t === 'arrow' ? 'pen' : 'arrow'))} className="p-2 rounded-lg" style={{ background: tool === 'arrow' ? COLORS.pink : 'transparent', color: tool === 'arrow' ? '#fff' : COLORS.ink }} aria-label="Add arrow">
          <ArrowUpRight size={16} />
        </button>
        <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
        <button onClick={undo} disabled={history.length === 0} className="p-2 rounded-lg border" style={{ color: history.length === 0 ? COLORS.graphite : COLORS.ink, background: history.length === 0 ? '#F5F5F6' : COLORS.pinkSoft, borderColor: COLORS.paperLine, opacity: history.length === 0 ? 0.5 : 1 }} aria-label="Undo last change" title="Undo">
          <Undo2 size={17} />
        </button>
        <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
        {tool === 'highlighter' ? (
          <div className="flex items-center gap-1.5">
            {HIGHLIGHT_COLORS.map((c) => (
              <button key={c.value} onClick={() => setHlColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: hlColor === c.value ? COLORS.ink : 'transparent', transform: hlColor === c.value ? 'scale(1.15)' : 'scale(1)' }} />
            ))}
          </div>
        ) : tool === 'sticky' ? (
          <div className="flex items-center gap-1.5">
            {STICKY_COLORS.map((c) => (
              <button key={c.value} onClick={() => setStickyColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: stickyColor === c.value ? COLORS.ink : 'transparent', transform: stickyColor === c.value ? 'scale(1.15)' : 'scale(1)' }} />
            ))}
            <span className="text-xs ml-1" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Tap the page to drop a note</span>
          </div>
        ) : tool === 'shape' ? (
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1">
              {SHAPE_TYPES.map((s) => (
                <button key={s.id} onClick={() => setShapeType(s.id)} title={s.label} className="w-8 h-8 rounded-lg flex items-center justify-center border-2" style={{ borderColor: shapeType === s.id ? COLORS.pink : COLORS.paperLine, background: shapeType === s.id ? COLORS.pinkSoft : '#fff', color: COLORS.ink }}>
                  {s.icon === 'square' && <Square size={14} />}
                  {s.icon === 'circle' && <Circle size={14} />}
                  {s.icon === 'triangle' && <Triangle size={14} />}
                  {s.icon === 'line' && <Minus size={14} />}
                </button>
              ))}
            </div>
            <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
            <div className="flex items-center gap-1">
              {FILL_MODES.map((m) => (
                <button key={m.id} onClick={() => setFillMode(m.id)} disabled={shapeType === 'line'} className="px-2 py-1 rounded-md text-xs border" style={{ background: fillMode === m.id ? COLORS.pink : '#fff', color: fillMode === m.id ? '#fff' : COLORS.ink, borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 700, opacity: shapeType === 'line' ? 0.4 : 1 }}>
                  {m.label}
                </button>
              ))}
            </div>
            <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
            <div className="flex items-center gap-1.5">
              {PEN_COLORS.map((c) => (
                <button key={c.value} onClick={() => setShapeColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: shapeColor === c.value ? COLORS.ink : 'transparent', transform: shapeColor === c.value ? 'scale(1.15)' : 'scale(1)' }} />
              ))}
            </div>
          </div>
        ) : tool === 'arrow' ? (
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              {PEN_COLORS.map((c) => (
                <button key={c.value} onClick={() => setArrowColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: arrowColor === c.value ? COLORS.ink : 'transparent', transform: arrowColor === c.value ? 'scale(1.15)' : 'scale(1)' }} />
              ))}
            </div>
            <span className="text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Drag across the page to draw an arrow — drag either end to reshape it</span>
          </div>
        ) : tool === 'text' || tool === 'link' ? (
          <span className="text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>
            {tool === 'text' ? 'Tap the page to add text' : 'Tap the page to add a link'}
          </span>
        ) : tool === 'pen' ? (
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5">
              {PEN_COLORS.map((c) => (
                <button key={c.value} onClick={() => setColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: color === c.value ? COLORS.pink : 'transparent', transform: color === c.value ? 'scale(1.15)' : 'scale(1)' }} />
              ))}
            </div>
            <div className="w-px h-6" style={{ background: COLORS.paperLine }} />
            <div className="flex items-center gap-2">
              {PEN_THICKNESSES.map((t) => (
                <button key={t.value} onClick={() => setThickness(t.value)} title={t.name} className="w-7 h-7 rounded-full flex items-center justify-center border-2" style={{ borderColor: thickness === t.value ? COLORS.pink : COLORS.paperLine, background: thickness === t.value ? COLORS.pinkSoft : '#fff' }}>
                  <span className="rounded-full" style={{ width: t.dot, height: t.dot, background: color }} />
                </button>
              ))}
            </div>
          </div>
        ) : null}
        <div className="flex-1" />
        <div className="flex items-center gap-1 mr-2">
          <button onClick={() => zoomStep(-0.25)} disabled={zoom <= 1} className="p-1.5 rounded-lg" style={{ color: zoom <= 1 ? COLORS.paperLine : COLORS.ink }} aria-label="Zoom out">
            <Minus size={14} />
          </button>
          <button onClick={resetZoom} className="text-xs px-1.5 text-center" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700, minWidth: 38 }} title="Reset zoom">
            {Math.round(zoom * 100)}%
          </button>
          <button onClick={() => zoomStep(0.25)} disabled={zoom >= 4} className="p-1.5 rounded-lg" style={{ color: zoom >= 4 ? COLORS.paperLine : COLORS.ink }} aria-label="Zoom in">
            <Plus size={14} />
          </button>
        </div>
        {pencilUsed && (tool === 'pen' || tool === 'highlighter' || tool === 'eraser') && (
          <button onClick={clearCanvas} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm" style={{ color: COLORS.red, fontFamily: FONT, fontWeight: 700 }}>
            <Trash2 size={14} /> Clear page
          </button>
        )}
      </div>
      <div
        ref={wrapRef}
        className="flex-1 relative"
        style={{ overflow: zoom > 1 ? 'auto' : 'hidden', background: COLORS.paperTint }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onWheel={handleWheel}
      >
        <div
          ref={zoomLayerRef}
          style={{
            position: 'absolute', inset: 0, transform: `scale(${zoom})`, transformOrigin: '0 0',
            ...bgStyle, userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none',
          }}
        >
          {pageMeta.hasPdfBg && (
            <canvas ref={pdfCanvasRef} className="absolute inset-0 w-full h-full" style={{ zIndex: 0 }} />
          )}
          {pageMeta.hasPdfBg && pdfRenderState === 'missing' && (
            <div className="absolute top-3 left-3 right-3 px-3 py-2 rounded-lg text-xs flex items-start gap-2" style={{ background: '#FDECEF', color: COLORS.red, border: `1px solid ${COLORS.paperLine}`, fontFamily: FONT, fontWeight: 700, zIndex: 4 }}>
              <AlertCircle size={14} className="shrink-0 mt-0.5" />
              <span>This notebook's PDF file couldn't be loaded. Try importing it again.</span>
            </div>
          )}
          {pageMeta.hasPdfBg && pdfRenderState === 'rendering' && (
            <div className="absolute top-3 left-3 right-3 px-3 py-2 rounded-lg text-xs flex items-center gap-2" style={{ background: '#F1F4F8', color: COLORS.graphite, fontFamily: FONT, fontWeight: 600, zIndex: 4 }}>
              <Loader2 size={13} className="animate-spin" /> Rendering this page…
            </div>
          )}
          <canvas
            ref={highlightCanvasRef}
            className="absolute inset-0 w-full h-full"
            style={{ zIndex: 1, pointerEvents: 'none', opacity: 0.32 }}
          />
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full touch-none"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
            onContextMenu={(e) => e.preventDefault()}
            style={{
              cursor: tool === 'eraser' ? 'cell' : (tool === 'text' || tool === 'link' || tool === 'sticky' || tool === 'shape' || tool === 'arrow') ? 'default' : 'crosshair',
              zIndex: 10,
              position: 'absolute',
              pointerEvents: isDrawingTool ? 'auto' : 'none',
              userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none',
            }}
          />
          <div style={{ position: 'absolute', inset: 0, zIndex: 2 }}>
            <OverlayLayer pageId={pageId} tool={tool} stickyColor={stickyColor} shapeType={shapeType} fillMode={fillMode} shapeColor={shapeColor} arrowColor={arrowColor} onConsumeTool={() => {}} />
          </div>
          {!loaded && (
            <div className="absolute inset-0 flex items-center justify-center text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600, zIndex: 3 }}>
              Loading page…
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- New page panel ----------
function NewPagePanel({ onCreate, onCancel, defaultPageType, defaultBgColor }) {
  const [pageType, setPageType] = useState(defaultPageType || 'ruled');
  const [bgColor, setBgColor] = useState(defaultBgColor || PAGE_BG_COLORS[0].value);
  const [title, setTitle] = useState('');

  return (
    <div className="p-3 rounded-lg mb-2" style={{ background: COLORS.paperTint, border: `1px solid ${COLORS.paperLine}` }}>
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Page title" className="w-full mb-2 px-2 py-1.5 text-sm rounded border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
      <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Layout</div>
      <div className="flex gap-2.5 mb-3 flex-wrap">
        {PAGE_TYPES.map((t) => (
          <PageTypePreview key={t} pageType={t} bgColor={bgColor} selected={pageType === t} onClick={() => setPageType(t)} label={t} />
        ))}
      </div>
      <div className="text-xs mb-1" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Color</div>
      <div className="flex gap-1.5 mb-3 flex-wrap">
        {PAGE_BG_COLORS.map((c) => (
          <button key={c.value} onClick={() => setBgColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: bgColor === c.value ? COLORS.pink : COLORS.paperLine }} />
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={() => onCreate({ title: title.trim() || 'Untitled page', pageType, bgColor })} className="flex-1 py-1.5 rounded-lg text-sm" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Create page</button>
        <button onClick={onCancel} className="px-3 py-1.5 rounded-lg text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cancel</button>
      </div>
    </div>
  );
}

// ---------- Notebook page view ----------
function PageThumbCard({ page, thumbUrl, active, onOpen, onRename, onDelete, onToggleBookmark, canDelete }) {
  const bgStyle = getPageStyle(page.pageType, page.bgColor);
  return (
    <div
      onClick={onOpen}
      className="group relative rounded-lg cursor-pointer overflow-hidden"
      style={{ border: active ? `2px solid ${COLORS.pink}` : `1px solid ${COLORS.paperLine}`, background: '#fff' }}
    >
      <div className="relative w-full" style={{ aspectRatio: '4 / 5', ...bgStyle }}>
        {thumbUrl && <img src={thumbUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />}
        <button
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => { e.stopPropagation(); onToggleBookmark(); }}
          className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.85)' }}
          aria-label="Bookmark page"
        >
          <Star size={12} color={page.bookmarked ? COLORS.pink : COLORS.graphite} fill={page.bookmarked ? COLORS.pink : 'none'} />
        </button>
        {canDelete && (
          <button
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            style={{ background: 'rgba(255,255,255,0.85)', color: COLORS.red }}
            aria-label="Delete page"
          >
            <X size={12} />
          </button>
        )}
      </div>
      <input
        value={page.title}
        onClick={(e) => e.stopPropagation()}
        onChange={(e) => onRename(e.target.value)}
        className="w-full px-2 py-1.5 text-xs bg-transparent outline-none truncate"
        style={{ fontFamily: FONT, fontWeight: 700, color: COLORS.ink }}
      />
    </div>
  );
}

function NotebookView({ notebookId, notebookTitle, defaultPageType, defaultBgColor, onBack, jumpPageId }) {
  const [pages, setPages] = useState([]);
  const [activePageId, setActivePageId] = useState(null);
  const [ready, setReady] = useState(false);
  const [showNewPage, setShowNewPage] = useState(false);
  const [thumbs, setThumbs] = useState({});
  const [railOpen, setRailOpen] = useState(true);

  const loadThumb = async (page) => {
    const val = await storageGet(`note-image:${page.id}`, null);
    setThumbs((prev) => ({ ...prev, [page.id]: val }));
  };

  useEffect(() => {
    (async () => {
      const saved = await storageGetWithRetry(`notebook-pages:${notebookId}`, [], 6, 250);
      let pageList = saved;
      if (!saved || saved.length === 0) {
        const firstPage = { id: `page-${Date.now()}`, title: 'Page 1', pageType: defaultPageType || 'ruled', bgColor: defaultBgColor || PAGE_BG_COLORS[0].value, date: new Date().toISOString() };
        await storageSet(`notebook-pages:${notebookId}`, [firstPage]);
        pageList = [firstPage];
      }
      const lastPageId = await storageGet(`notebook-lastpage:${notebookId}`, null);
      setPages(pageList);
      const startId = jumpPageId && pageList.find((p) => p.id === jumpPageId)
        ? jumpPageId
        : lastPageId && pageList.find((p) => p.id === lastPageId)
        ? lastPageId
        : pageList[0].id;
      setActivePageId(startId);
      pageList.forEach((p) => loadThumb(p));
      setReady(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notebookId]);

  const persistPages = async (updated) => {
    setPages(updated);
    await storageSet(`notebook-pages:${notebookId}`, updated);
  };

  const switchPage = async (id) => {
    if (activePageId && activePageId !== id) {
      const prevPage = pages.find((p) => p.id === activePageId);
      if (prevPage && !prevPage.hasPdfBg) loadThumb(prevPage);
    }
    setActivePageId(id);
    await storageSet(`notebook-lastpage:${notebookId}`, id);
  };

  const createPage = async ({ title, pageType, bgColor }) => {
    const page = { id: `page-${Date.now()}`, title, pageType, bgColor, date: new Date().toISOString() };
    const updated = [...pages, page];
    await persistPages(updated);
    setActivePageId(page.id);
    await storageSet(`notebook-lastpage:${notebookId}`, page.id);
    setShowNewPage(false);
  };

  const deletePage = async (id) => {
    if (pages.length === 1) return;
    const updated = pages.filter((p) => p.id !== id);
    await persistPages(updated);
    if (activePageId === id) {
      setActivePageId(updated[0].id);
      await storageSet(`notebook-lastpage:${notebookId}`, updated[0].id);
    }
  };

  const renamePage = async (id, title) => persistPages(pages.map((p) => (p.id === id ? { ...p, title } : p)));
  const updatePageDate = async (id, dateStr) => persistPages(pages.map((p) => (p.id === id ? { ...p, date: new Date(dateStr).toISOString() } : p)));
  const toggleBookmark = async (id) => persistPages(pages.map((p) => (p.id === id ? { ...p, bookmarked: !p.bookmarked } : p)));

  const activePage = pages.find((p) => p.id === activePageId);

  if (!ready) return <div className="p-8 text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Loading…</div>;

  return (
    <div className="flex h-full" style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}>
      <div className="shrink-0 border-r flex flex-col transition-all" style={{ width: railOpen ? 190 : 44, borderColor: COLORS.paperLine, background: '#FFFFFF' }}>
        <div className={`px-2 py-3 flex border-b ${railOpen ? 'items-center gap-1.5' : 'flex-col items-center gap-2'}`} style={{ borderColor: COLORS.paperLine }}>
          <button onClick={onBack} className="p-1 rounded shrink-0" style={{ color: COLORS.graphite }} aria-label="Back to library"><ArrowLeft size={15} /></button>
          {railOpen && <span className="text-sm truncate flex-1" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>{notebookTitle}</span>}
          <button onClick={() => setRailOpen((v) => !v)} className="p-1 rounded shrink-0" style={{ color: COLORS.pink, background: COLORS.pinkSoft }} aria-label={railOpen ? 'Close pages panel' : 'Open pages panel'}>
            {railOpen ? <ChevronLeft size={15} /> : <ChevronRight size={15} />}
          </button>
        </div>
        {railOpen && (
          <>
            <div className="px-2 py-2 flex items-center justify-between">
              <span className="text-xs uppercase tracking-wide" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>Pages</span>
              <button onClick={() => setShowNewPage(true)} className="p-1 rounded" style={{ color: COLORS.pink }} aria-label="Add page"><Plus size={15} /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-2 pb-3 space-y-2.5">
              {showNewPage && <NewPagePanel onCreate={createPage} onCancel={() => pages.length > 0 && setShowNewPage(false)} defaultPageType={defaultPageType} defaultBgColor={defaultBgColor} />}
              {pages.map((p) => (
                <PageThumbCard
                  key={p.id}
                  page={p}
                  thumbUrl={thumbs[p.id]}
                  active={activePageId === p.id}
                  onOpen={() => switchPage(p.id)}
                  onRename={(title) => renamePage(p.id, title)}
                  onDelete={() => deletePage(p.id)}
                  onToggleBookmark={() => toggleBookmark(p.id)}
                  canDelete={pages.length > 1}
                />
              ))}
            </div>
          </>
        )}
      </div>
      <div className="flex-1 min-w-0 flex flex-col">
        {activePage && (
          <>
            <div className="px-4 py-1.5 flex items-center gap-2 border-b" style={{ borderColor: COLORS.paperLine, background: '#FFFFFF' }}>
              <CalendarIcon size={12} color={COLORS.graphite} />
              <input type="date" value={dateKey(activePage.date)} onChange={(e) => updatePageDate(activePage.id, e.target.value)} className="text-xs outline-none" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }} />
            </div>
            <div className="flex-1 min-h-0">
              <DrawingCanvas key={activePage.id} pageId={activePage.id} pageMeta={activePage} pdfDoc={null} pdfLoadError={false} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ---------- PDF Notebook (dedicated reader — page-by-page, like a real PDF viewer) ----------
function PdfNotebookView({ notebookId, notebookTitle, onBack }) {
  const [pdfDoc, setPdfDoc] = useState(null);
  const [pageCount, setPageCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const doc = await loadPdfDocument(notebookId);
        if (!doc) {
          setLoadError(true);
        } else {
          setPdfDoc(doc);
          setPageCount(doc.numPages);
          const lastPage = await storageGet(`notebook-lastpage:${notebookId}`, null);
          const startPage = lastPage ? parseInt(lastPage, 10) : 1;
          setCurrentPage(startPage >= 1 && startPage <= doc.numPages ? startPage : 1);
        }
      } catch (e) {
        console.error('Failed to load PDF document', e);
        setLoadError(true);
      }
      setReady(true);
    })();
  }, [notebookId]);

  const goToPage = (n) => {
    const clamped = Math.max(1, Math.min(pageCount, n));
    setCurrentPage(clamped);
    storageSet(`notebook-lastpage:${notebookId}`, String(clamped));
  };

  if (!ready) return <div className="p-8 text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Loading…</div>;

  if (loadError) {
    return (
      <div className="h-full flex flex-col">
        <div className="px-5 py-4 flex items-center gap-2 shrink-0 border-b" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
          <button onClick={onBack} className="p-1 rounded" style={{ color: COLORS.graphite }} aria-label="Back to library"><ArrowLeft size={15} /></button>
          <span className="text-base" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>{notebookTitle}</span>
        </div>
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-sm text-center">
            <AlertCircle size={24} color={COLORS.red} className="mx-auto mb-2" />
            <p className="text-sm" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>Couldn't load this PDF.</p>
            <p className="text-xs mt-1" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>Try removing this notebook and importing the file again.</p>
          </div>
        </div>
      </div>
    );
  }

  const pageId = `${notebookId}-p${currentPage}`;
  const pageMeta = { hasPdfBg: true, pdfPageNumber: currentPage, pageType: 'pdf', bgColor: '#FFFFFF' };

  return (
    <div className="flex flex-col h-full" style={{ userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}>
      <div className="px-5 py-3 flex items-center gap-3 shrink-0 border-b" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
        <button onClick={onBack} className="p-1 rounded shrink-0" style={{ color: COLORS.graphite }} aria-label="Back to library"><ArrowLeft size={15} /></button>
        <span className="text-base truncate flex-1" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>{notebookTitle}</span>
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={() => goToPage(currentPage - 1)} disabled={currentPage <= 1} className="p-1.5 rounded-lg" style={{ color: currentPage <= 1 ? COLORS.paperLine : COLORS.pink }} aria-label="Previous page">
            <ChevronLeft size={18} />
          </button>
          <span className="text-xs px-2" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Page {currentPage} of {pageCount}</span>
          <button onClick={() => goToPage(currentPage + 1)} disabled={currentPage >= pageCount} className="p-1.5 rounded-lg" style={{ color: currentPage >= pageCount ? COLORS.paperLine : COLORS.pink }} aria-label="Next page">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
      <div className="flex-1 min-h-0">
        <DrawingCanvas key={pageId} pageId={pageId} pageMeta={pageMeta} pdfDoc={pdfDoc} pdfLoadError={loadError} />
      </div>
    </div>
  );
}


function CoverPicker({ color, design, photoUrl, onColorChange, onDesignChange, onPhotoChange, onRemovePhoto }) {
  const [mode, setMode] = useState(photoUrl ? 'photo' : 'color');
  const fileRef = useRef(null);

  const handleFile = async (file) => {
    if (!file) return;
    const dataUrl = await readFileAsDataUrl(file);
    onPhotoChange(dataUrl);
    setMode('photo');
  };

  return (
    <div>
      <div className="flex gap-2 mb-3">
        <button onClick={() => setMode('color')} className="flex-1 py-1.5 rounded-lg text-xs flex items-center justify-center gap-1.5" style={{ background: mode === 'color' ? COLORS.pink : COLORS.paperTint, color: mode === 'color' ? '#fff' : COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>
          Color
        </button>
        <button onClick={() => setMode('photo')} className="flex-1 py-1.5 rounded-lg text-xs flex items-center justify-center gap-1.5" style={{ background: mode === 'photo' ? COLORS.pink : COLORS.paperTint, color: mode === 'photo' ? '#fff' : COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>
          <ImageIcon size={12} /> Photo
        </button>
      </div>

      {mode === 'color' ? (
        <>
          <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cover color</div>
          <div className="flex gap-2 mb-3 flex-wrap">
            {COVER_COLORS.map((c) => (
              <button key={c} onClick={() => onColorChange(c)} className="w-7 h-7 rounded-full border-2" style={{ background: c, borderColor: color === c ? COLORS.pink : 'transparent' }} />
            ))}
          </div>
          <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cover design</div>
          <div className="flex gap-2 mb-1">
            {COVER_DESIGNS.map((d) => (
              <button key={d.id} onClick={() => onDesignChange(d.id)} className="w-11 h-14 rounded-md border-2 overflow-hidden" style={{ ...getCoverStyle(d.id, color), borderColor: design === d.id ? COLORS.pink : COLORS.paperLine }} title={d.label} />
            ))}
          </div>
        </>
      ) : (
        <div>
          {photoUrl ? (
            <div className="relative w-24 h-32 rounded-md overflow-hidden mb-2 border" style={{ borderColor: COLORS.paperLine }}>
              <img src={photoUrl} alt="Cover preview" className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="w-24 h-32 rounded-md mb-2 border-2 border-dashed flex items-center justify-center" style={{ borderColor: COLORS.paperLine, color: COLORS.graphite }}>
              <ImageIcon size={20} />
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={() => fileRef.current?.click()} className="px-3 py-1.5 rounded-lg text-xs" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>
              {photoUrl ? 'Change photo' : 'Upload photo'}
            </button>
            {photoUrl && (
              <button onClick={() => { onRemovePhoto(); setMode('color'); }} className="px-3 py-1.5 rounded-lg text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Remove</button>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
        </div>
      )}
    </div>
  );
}

// ---------- Notebook cover: styled to look like a real bound notebook ----------
function NotebookCover({ nb, photoUrl, onOpen, onEdit }) {
  const bgStyle = photoUrl
    ? { backgroundImage: `url(${photoUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : getCoverStyle(nb.design || 'solid', nb.color);

  return (
    <div className="relative group" style={{ aspectRatio: '3 / 4' }}>
      <button
        onClick={onOpen}
        className="absolute inset-0 overflow-hidden text-left"
        style={{ ...bgStyle, borderTopLeftRadius: 6, borderBottomLeftRadius: 6, borderTopRightRadius: 14, borderBottomRightRadius: 14, boxShadow: '0 4px 14px rgba(24,24,27,0.18), 0 1px 3px rgba(24,24,27,0.15)', border: 'none', padding: 0, cursor: 'pointer' }}
      >
        {/* spine / binding edge */}
        <div className="absolute left-0 top-0 bottom-0" style={{ width: 12, background: 'rgba(0,0,0,0.28)' }} />
        <div className="absolute left-0 top-0 bottom-0 flex flex-col justify-evenly items-center py-2" style={{ width: 12 }}>
          {Array.from({ length: 7 }).map((_, i) => (
            <span key={i} className="rounded-full" style={{ width: 4, height: 4, background: 'rgba(255,255,255,0.55)' }} />
          ))}
        </div>
        {/* stacked page edge on the right */}
        <div className="absolute" style={{ right: 0, top: 6, bottom: 6, width: 3, background: 'repeating-linear-gradient(180deg, rgba(255,255,255,0.7) 0px, rgba(255,255,255,0.7) 2px, rgba(0,0,0,0.06) 2px, rgba(0,0,0,0.06) 4px)' }} />
        {/* title, centered */}
        <div className="absolute inset-0 flex items-center justify-center px-3" style={{ left: 14, right: 6 }}>
          <span className="text-sm text-white text-center px-2.5 py-1.5 rounded-md" style={{ fontFamily: FONT, fontWeight: 800, background: 'rgba(0,0,0,0.32)', textShadow: '0 1px 3px rgba(0,0,0,0.35)' }}>
            {nb.title}
          </span>
        </div>
        {nb.isPdfBook && (
          <div className="absolute flex items-center gap-1 px-1.5 py-0.5 rounded-md" style={{ top: 8, left: 18, background: 'rgba(255,255,255,0.9)' }}>
            <FileText size={10} color={COLORS.pinkDeep} />
            <span className="text-xs" style={{ color: COLORS.pinkDeep, fontFamily: FONT, fontWeight: 800 }}>PDF</span>
          </div>
        )}
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); onEdit(); }}
        className="absolute rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ top: 8, right: 8, width: 24, height: 24, background: 'rgba(255,255,255,0.9)', color: COLORS.pinkDeep, border: 'none' }}
        aria-label="Edit cover"
      >
        <Pencil size={12} />
      </button>
    </div>
  );
}

// ---------- Library ----------
function Library({ openNotebookId, setOpenNotebookId, jumpPageId, notebooks, setNotebooks, coverPhotos, setCoverPhotos, ready }) {
  const [showNew, setShowNew] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newColor, setNewColor] = useState(COVER_COLORS[0]);
  const [newDesign, setNewDesign] = useState('solid');
  const [newPhoto, setNewPhoto] = useState(null);
  const [newDefaultPageType, setNewDefaultPageType] = useState('ruled');
  const [newDefaultPageColor, setNewDefaultPageColor] = useState(PAGE_BG_COLORS[0].value);
  const [editingCoverId, setEditingCoverId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editColor, setEditColor] = useState(COVER_COLORS[0]);
  const [editDesign, setEditDesign] = useState('solid');
  const [editPhoto, setEditPhoto] = useState(null);
  const [importing, setImporting] = useState(null);
  const [pendingPdf, setPendingPdf] = useState(null); // { name, buf, pageCount, pdfDoc } awaiting review before save
  const [pdfTitle, setPdfTitle] = useState('');
  const [pdfColor, setPdfColor] = useState(COVER_COLORS[0]);
  const [pdfDesign, setPdfDesign] = useState('solid');
  const [pdfPhoto, setPdfPhoto] = useState(null);
  const fileInputRef = useRef(null);

  const createNotebook = async () => {
    const id = `nb-${Date.now()}`;
    const untitledCount = notebooks.filter((n) => /^Untitled Notebook( \d+)?$/.test(n.title)).length;
    const fallbackTitle = untitledCount > 0 ? `Untitled Notebook ${untitledCount + 1}` : 'Untitled Notebook';
    const nb = { id, title: newTitle.trim() || fallbackTitle, color: newColor, design: newDesign, hasCoverPhoto: !!newPhoto, defaultPageType: newDefaultPageType, defaultBgColor: newDefaultPageColor, createdAt: new Date().toISOString(), lastOpenedAt: new Date().toISOString() };
    const updated = [...notebooks, nb];
    setNotebooks(updated);
    await storageSet('notebooks-index', updated);
    if (newPhoto) {
      await storageSet(`note-cover:${id}`, newPhoto);
      setCoverPhotos((prev) => ({ ...prev, [id]: newPhoto }));
    }
    setNewTitle('');
    setNewPhoto(null);
    setNewDesign('solid');
    setNewDefaultPageType('ruled');
    setNewDefaultPageColor(PAGE_BG_COLORS[0].value);
    setShowNew(false);
    setOpenNotebookId(id);
  };

  const openNotebook = async (id) => {
    const updated = notebooks.map((n) => (n.id === id ? { ...n, lastOpenedAt: new Date().toISOString() } : n));
    setNotebooks(updated);
    setOpenNotebookId(id);
    await storageSet('notebooks-index', updated);
  };

  const openCoverEditor = (nb) => {
    setEditingCoverId(nb.id);
    setEditTitle(nb.title);
    setEditColor(nb.color || COVER_COLORS[0]);
    setEditDesign(nb.design || 'solid');
    setEditPhoto(nb.hasCoverPhoto ? coverPhotos[nb.id] || null : null);
  };

  const saveCoverEdit = async () => {
    const updated = notebooks.map((n) => (n.id === editingCoverId ? { ...n, title: editTitle.trim() || n.title, color: editColor, design: editDesign, hasCoverPhoto: !!editPhoto } : n));
    setNotebooks(updated);
    await storageSet('notebooks-index', updated);
    if (editPhoto) {
      await storageSet(`note-cover:${editingCoverId}`, editPhoto);
      setCoverPhotos((prev) => ({ ...prev, [editingCoverId]: editPhoto }));
    } else {
      setCoverPhotos((prev) => { const next = { ...prev }; delete next[editingCoverId]; return next; });
    }
    setEditingCoverId(null);
  };

  const handlePdfFile = async (file) => {
    if (!file) return;
    setImporting({ current: 0, total: 0, name: file.name, error: null });
    let stage = 'loading the PDF renderer';
    try {
      const pdfjsLib = await loadPdfJs();
      stage = 'reading the file';
      const buf = await file.arrayBuffer();
      stage = 'opening the PDF';
      const pdf = await pdfjsLib.getDocument({ data: buf.slice(0) }).promise;
      const total = pdf.numPages;
      setImporting(null);
      // Nothing is saved yet — show a review step so the name/cover can be
      // set before this becomes a real notebook.
      setPendingPdf({ name: file.name, buf, pageCount: total, pdfDoc: pdf });
      setPdfTitle(file.name.replace(/\.pdf$/i, ''));
      setPdfColor(COVER_COLORS[Math.floor(Math.random() * COVER_COLORS.length)]);
      setPdfDesign('solid');
      setPdfPhoto(null);
    } catch (e) {
      console.error(`PDF import failed at stage "${stage}":`, e);
      const detail = e?.message ? `${e.message}` : 'unknown error';
      setImporting({ error: `Import failed while ${stage} — ${detail}` });
      setTimeout(() => setImporting(null), 6500);
    }
  };

  const savePdfNotebook = async () => {
    if (!pendingPdf) return;
    setImporting({ current: pendingPdf.pageCount, total: pendingPdf.pageCount, name: pendingPdf.name, error: null, settling: true });
    try {
      const nbId = `nb-${Date.now()}`;
      await storePdfSourceFile(nbId, pendingPdf.buf);
      pdfDocCache.set(nbId, pendingPdf.pdfDoc); // reuse the copy we already parsed
      const nb = { id: nbId, title: pdfTitle.trim() || pendingPdf.name.replace(/\.pdf$/i, ''), color: pdfColor, design: pdfDesign, hasCoverPhoto: !!pdfPhoto, isPdfBook: true, createdAt: new Date().toISOString(), lastOpenedAt: new Date().toISOString() };
      const updatedNbs = [...notebooks, nb];
      setNotebooks(updatedNbs);
      await storageSet('notebooks-index', updatedNbs);
      if (pdfPhoto) {
        await storageSet(`note-cover:${nbId}`, pdfPhoto);
        setCoverPhotos((prev) => ({ ...prev, [nbId]: pdfPhoto }));
      }
      await new Promise((r) => setTimeout(r, 500));
      setImporting(null);
      setPendingPdf(null);
      setShowNew(false);
      setOpenNotebookId(nb.id);
    } catch (e) {
      console.error('Saving the PDF notebook failed:', e);
      setImporting({ error: `Couldn't save this notebook — ${e?.message || 'unknown error'}` });
      setTimeout(() => setImporting(null), 6500);
    }
  };

  const cancelPdfImport = () => {
    setPendingPdf(null);
    setPdfTitle('');
    setPdfPhoto(null);
  };

  if (!ready) return <div className="p-8 text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Loading library…</div>;

  const active = notebooks.find((n) => n.id === openNotebookId);
  if (active) {
    if (active.isPdfBook) {
      return <PdfNotebookView notebookId={active.id} notebookTitle={active.title} onBack={() => setOpenNotebookId(null)} />;
    }
    return <NotebookView notebookId={active.id} notebookTitle={active.title} defaultPageType={active.defaultPageType} defaultBgColor={active.defaultBgColor} onBack={() => setOpenNotebookId(null)} jumpPageId={jumpPageId} />;
  }

  if (showNew) {
    if (pendingPdf) {
      return (
        <div className="h-full overflow-y-auto" style={{ background: COLORS.paperTint }}>
          <div className="px-5 py-4 flex items-center gap-2 border-b" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
            <button onClick={cancelPdfImport} disabled={!!importing} className="p-1 rounded" style={{ color: COLORS.graphite }} aria-label="Cancel"><ArrowLeft size={15} /></button>
            <span className="text-base" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>Save PDF Notebook</span>
          </div>
          <div className="max-w-sm mx-auto p-6">
            <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-lg text-xs" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}`, color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>
              <FileText size={14} color={COLORS.pink} />
              <span>{pendingPdf.name} — {pendingPdf.pageCount} page{pendingPdf.pageCount === 1 ? '' : 's'}</span>
            </div>
            <input value={pdfTitle} onChange={(e) => setPdfTitle(e.target.value)} placeholder="Untitled Notebook" autoFocus className="w-full mb-4 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
            <CoverPicker
              color={pdfColor} design={pdfDesign} photoUrl={pdfPhoto}
              onColorChange={setPdfColor} onDesignChange={setPdfDesign}
              onPhotoChange={setPdfPhoto} onRemovePhoto={() => setPdfPhoto(null)}
            />
            {importing && (
              <div className="mt-4 flex items-center gap-2 px-3 py-2 rounded-lg text-sm" style={{ background: importing.error ? '#FDECEF' : '#FFFFFF', color: importing.error ? COLORS.red : COLORS.ink, border: `1px solid ${COLORS.paperLine}`, fontFamily: FONT, fontWeight: 600 }}>
                {importing.error ? <AlertCircle size={14} /> : <Loader2 size={14} className="animate-spin" color={COLORS.pink} />}
                <span>{importing.error || `Saving ${importing.name}…`}</span>
              </div>
            )}
            <div className="flex gap-2 mt-6">
              <button onClick={savePdfNotebook} disabled={!!importing} className="flex-1 py-2.5 rounded-lg text-sm" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700, opacity: importing ? 0.7 : 1 }}>Save notebook</button>
              <button onClick={cancelPdfImport} disabled={!!importing} className="px-4 py-2.5 rounded-lg text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cancel</button>
            </div>
          </div>
        </div>
      );
    }
    return (
      <div className="h-full overflow-y-auto" style={{ background: COLORS.paperTint }}>
        <div className="px-5 py-4 flex items-center gap-2 border-b" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
          <button onClick={() => { setShowNew(false); setNewPhoto(null); }} className="p-1 rounded" style={{ color: COLORS.graphite }} aria-label="Back to library"><ArrowLeft size={15} /></button>
          <span className="text-base" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>New Notebook</span>
        </div>
        <div className="max-w-sm mx-auto p-6">
          <button onClick={() => fileInputRef.current?.click()} disabled={!!importing} className="w-full mb-3 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs border-2 border-dashed" style={{ color: COLORS.pink, borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 700, background: '#FFFFFF', opacity: importing ? 0.6 : 1 }}>
            <FileText size={13} /> {importing ? 'Importing…' : 'Or import a PDF instead'}
          </button>
          {importing && (
            <div className="mb-4 flex items-center gap-2 px-3 py-2 rounded-lg text-sm" style={{ background: importing.error ? '#FDECEF' : '#FFFFFF', color: importing.error ? COLORS.red : COLORS.ink, border: `1px solid ${COLORS.paperLine}`, fontFamily: FONT, fontWeight: 600 }}>
              {importing.error ? <AlertCircle size={14} /> : <Loader2 size={14} className="animate-spin" color={COLORS.pink} />}
              <span>{importing.error || (importing.settling ? `Finishing up ${importing.name}…` : `Rendering ${importing.name}${importing.total ? ` — page ${importing.current}/${importing.total}` : '…'}`)}</span>
            </div>
          )}
          <input ref={fileInputRef} type="file" accept="application/pdf" className="hidden" onChange={(e) => handlePdfFile(e.target.files?.[0])} />
          <div className="flex items-center gap-2 mb-4">
            <div className="flex-1 h-px" style={{ background: COLORS.paperLine }} />
            <span className="text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>or set up a blank notebook</span>
            <div className="flex-1 h-px" style={{ background: COLORS.paperLine }} />
          </div>
          <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Untitled Notebook" autoFocus className="w-full mb-4 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
          <CoverPicker
            color={newColor} design={newDesign} photoUrl={newPhoto}
            onColorChange={setNewColor} onDesignChange={setNewDesign}
            onPhotoChange={setNewPhoto} onRemovePhoto={() => setNewPhoto(null)}
          />
          <div className="mt-4 pt-4" style={{ borderTop: `1px solid ${COLORS.paperLine}` }}>
            <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Default page color</div>
            <div className="flex gap-1.5 mb-3 flex-wrap">
              {PAGE_BG_COLORS.map((c) => (
                <button key={c.value} onClick={() => setNewDefaultPageColor(c.value)} title={c.name} className="w-6 h-6 rounded-full border-2" style={{ background: c.value, borderColor: newDefaultPageColor === c.value ? COLORS.pink : COLORS.paperLine }} />
              ))}
            </div>
            <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Default page layout</div>
            <p className="text-xs mb-2" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>Used for new pages in this notebook — you can still change it per page.</p>
            <div className="flex gap-2.5 flex-wrap">
              {PAGE_TYPES.map((t) => (
                <PageTypePreview key={t} pageType={t} bgColor={newDefaultPageColor} selected={newDefaultPageType === t} onClick={() => setNewDefaultPageType(t)} label={t} />
              ))}
            </div>
          </div>
          <div className="flex gap-2 mt-6">
            <button onClick={createNotebook} className="flex-1 py-2.5 rounded-lg text-sm" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Create notebook</button>
            <button onClick={() => { setShowNew(false); setNewPhoto(null); }} className="px-4 py-2.5 rounded-lg text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cancel</button>
          </div>
        </div>
      </div>
    );
  }

  const editingNb = notebooks.find((n) => n.id === editingCoverId);

  return (
    <div className="h-full flex flex-col">
      <div className="px-5 py-4 flex items-center gap-2 shrink-0 border-b" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
        <span className="text-lg" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink, letterSpacing: '-0.01em' }}>Library</span>
      </div>
      <div className="flex-1 overflow-y-auto p-6" style={{ background: COLORS.paperTint }}>
        {importing && (
          <div className="mb-4 max-w-md flex items-center gap-2 px-3 py-2 rounded-lg text-sm" style={{ background: importing.error ? '#FDECEF' : '#FFFFFF', color: importing.error ? COLORS.red : COLORS.ink, border: `1px solid ${COLORS.paperLine}`, fontFamily: FONT, fontWeight: 600 }}>
            {importing.error ? <AlertCircle size={14} /> : <Loader2 size={14} className="animate-spin" color={COLORS.pink} />}
            <span>{importing.error || (importing.settling ? `Finishing up ${importing.name}…` : `Rendering ${importing.name}${importing.total ? ` — page ${importing.current}/${importing.total}` : '…'}`)}</span>
          </div>
        )}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-5 max-w-3xl">
          {[...notebooks].sort((a, b) => new Date(b.lastOpenedAt || b.createdAt) - new Date(a.lastOpenedAt || a.createdAt)).map((nb) => (
            <NotebookCover key={nb.id} nb={nb} photoUrl={nb.hasCoverPhoto ? coverPhotos[nb.id] : null} onOpen={() => openNotebook(nb.id)} onEdit={() => openCoverEditor(nb)} />
          ))}
          <button onClick={() => setShowNew(true)} className="rounded-xl flex flex-col items-center justify-center gap-2 border-2 border-dashed" style={{ aspectRatio: '3 / 4', borderColor: COLORS.paperLine, color: COLORS.pink, background: '#FFFFFF' }}>
            <Plus size={20} />
            <span className="text-xs" style={{ fontFamily: FONT, fontWeight: 700 }}>New notebook</span>
        </button>
        <input ref={fileInputRef} type="file" accept="application/pdf" className="hidden" onChange={(e) => handlePdfFile(e.target.files?.[0])} />
      </div>

      {editingNb && (
        <div className="mt-6 max-w-sm p-4 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
          <div className="text-sm mb-3" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>Edit notebook</div>
          <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Name</div>
          <input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} placeholder="Untitled Notebook" className="w-full mb-4 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
          <CoverPicker
            color={editColor} design={editDesign} photoUrl={editPhoto}
            onColorChange={setEditColor} onDesignChange={setEditDesign}
            onPhotoChange={setEditPhoto} onRemovePhoto={() => setEditPhoto(null)}
          />
          <div className="flex gap-2 mt-4">
            <button onClick={saveCoverEdit} className="flex-1 py-2 rounded-lg text-sm" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Save</button>
            <button onClick={() => setEditingCoverId(null)} className="px-3 py-2 rounded-lg text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>Cancel</button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}

// ---------- Planner ----------
function Planner({ assignments, setAssignments, ready }) {
  const [icalUrl, setIcalUrl] = useState('');
  const [pastedICS, setPastedICS] = useState('');
  const [showPaste, setShowPaste] = useState(false);
  const [importStatus, setImportStatus] = useState(null);
  const [newTitle, setNewTitle] = useState('');
  const [newDue, setNewDue] = useState(localDateInputValue());
  const [newTime, setNewTime] = useState(localTimeInputValue());
  const [newDuration, setNewDuration] = useState(1);

  useEffect(() => {
    (async () => {
      const url = await storageGet('ical-url', '');
      setIcalUrl(url);
    })();
  }, []);

  const persist = async (list) => {
    setAssignments(list);
    await storageSet('assignments', list);
  };

  const mergeEvents = async (events) => {
    setAssignments((prev) => {
      const existingIds = new Set(prev.map((a) => a.id));
      const merged = [...prev, ...events.filter((e) => !existingIds.has(e.id))];
      storageSet('assignments', merged);
      return merged;
    });
    await storageSet('ical-url', icalUrl);
  };

  const importFromUrl = async () => {
    if (!icalUrl.trim()) return;
    setImportStatus({ type: 'loading', message: 'Fetching feed…' });
    try {
      const res = await fetch(icalUrl.trim());
      if (!res.ok) throw new Error('bad response');
      const text = await res.text();
      const events = parseICS(text);
      if (events.length === 0) throw new Error('no events found');
      await mergeEvents(events);
      setImportStatus({ type: 'success', message: `Imported ${events.length} item(s) from the feed.` });
    } catch (e) {
      setImportStatus({ type: 'error', message: "Couldn't fetch that feed directly (most university networks block cross-site requests like this). Paste the .ics file's contents instead below." });
      setShowPaste(true);
    }
  };

  const importFromPaste = async () => {
    if (!pastedICS.trim()) return;
    const events = parseICS(pastedICS);
    if (events.length === 0) {
      setImportStatus({ type: 'error', message: "Couldn't find any events in that text — check it's a full .ics export." });
      return;
    }
    await mergeEvents(events);
    setImportStatus({ type: 'success', message: `Imported ${events.length} item(s) from pasted data.` });
    setPastedICS('');
    setShowPaste(false);
  };

  const addManual = async () => {
    if (!newTitle.trim()) return;
    let dueISO = null;
    if (newDue) {
      const d = new Date(newDue);
      if (newTime) {
        const [h, m] = newTime.split(':').map(Number);
        d.setHours(h, m);
      }
      dueISO = d.toISOString();
    }
    const item = { id: `manual-${Date.now()}`, title: newTitle.trim(), due: dueISO, dueTime: newTime || null, duration: newDuration, notes: '', done: false, source: 'manual' };
    await persist([...assignments, item]);
    setNewTitle('');
    setNewDue(localDateInputValue());
    setNewTime(localTimeInputValue());
    setNewDuration(1);
  };

  const toggleDone = async (id) => persist(assignments.map((a) => (a.id === id ? { ...a, done: !a.done } : a)));
  const removeItem = async (id) => persist(assignments.filter((a) => a.id !== id));

  const sorted = [...assignments].sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    if (!a.due) return 1;
    if (!b.due) return -1;
    return new Date(a.due) - new Date(b.due);
  });

  if (!ready) return <div className="p-8 text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Loading planner…</div>;

  return (
    <div className="h-full overflow-y-auto" style={{ background: COLORS.paperTint }}>
      <div className="max-w-2xl mx-auto px-6 py-6">
        <div className="mb-6 p-4 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
          <div className="flex items-center gap-2 mb-2" style={{ color: COLORS.ink }}>
            <Link2 size={15} color={COLORS.pink} />
            <span className="text-sm" style={{ fontFamily: FONT, fontWeight: 800 }}>Import from Moodle</span>
          </div>
          <p className="text-xs mb-3" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>In Moodle: Calendar → gear icon → "Export calendar" → copy the internal address (webcal/.ics link).</p>
          <div className="flex gap-2">
            <input type="text" value={icalUrl} onChange={(e) => setIcalUrl(e.target.value)} placeholder="https://your-moodle.edu/calendar/export_execute.php?..." className="flex-1 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600, fontSize: '12px' }} />
            <button onClick={importFromUrl} className="px-3 py-2 rounded-lg text-sm flex items-center gap-1.5 shrink-0" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}><Upload size={14} /> Import</button>
          </div>
          {importStatus && (
            <div className="mt-3 flex items-start gap-2 text-xs px-3 py-2 rounded-lg" style={{ background: importStatus.type === 'error' ? '#FDECEF' : importStatus.type === 'success' ? '#EAF7F3' : '#F7F7FA', color: importStatus.type === 'error' ? COLORS.red : importStatus.type === 'success' ? COLORS.green : COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>
              <AlertCircle size={14} className="mt-0.5 shrink-0" />
              <span>{importStatus.message}</span>
            </div>
          )}
          {showPaste && (
            <div className="mt-3">
              <textarea value={pastedICS} onChange={(e) => setPastedICS(e.target.value)} placeholder="Paste the full .ics file contents here (BEGIN:VCALENDAR ... END:VCALENDAR)" rows={5} className="w-full px-3 py-2 text-xs rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
              <button onClick={importFromPaste} className="mt-2 px-3 py-1.5 rounded-lg text-xs" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Parse pasted calendar</button>
            </div>
          )}
        </div>

        <div className="mb-6 p-4 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
          <div className="flex items-center gap-2 mb-3" style={{ color: COLORS.ink }}>
            <Plus size={15} color={COLORS.pink} />
            <span className="text-sm" style={{ fontFamily: FONT, fontWeight: 800 }}>Add a reminder</span>
          </div>
          <input type="text" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Assignment name" className="w-full mb-2 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
          <div className="flex gap-2 mb-2">
            <input type="date" value={newDue} onChange={(e) => setNewDue(e.target.value)} className="flex-1 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
            <input type="time" value={newTime} onChange={(e) => setNewTime(e.target.value)} className="flex-1 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
          </div>
          <div className="mb-2">
            <div className="text-xs mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 700 }}>How long will it take?</div>
            <div className="flex gap-1.5">
              {DURATION_OPTIONS.map((d) => (
                <button key={d.value} onClick={() => setNewDuration(d.value)} className="px-3 py-1.5 rounded-lg text-xs border" style={{ background: newDuration === d.value ? COLORS.pink : '#fff', color: newDuration === d.value ? '#fff' : COLORS.ink, borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 700 }}>{d.label}</button>
              ))}
            </div>
          </div>
          <button onClick={addManual} className="w-full py-2 rounded-lg text-sm" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Add reminder</button>
        </div>

        <div className="space-y-2">
          {sorted.length === 0 && <p className="text-sm text-center py-10" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Nothing on the syllabus yet — import a feed or add something above.</p>}
          {sorted.map((a) => {
            const status = dueStatus(a);
            const durationLabel = DURATION_OPTIONS.find((d) => d.value === a.duration)?.label;
            return (
              <div key={a.id} className="flex items-start gap-3 px-4 py-3 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
                <button onClick={() => toggleDone(a.id)} className="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5" style={{ borderColor: a.done ? COLORS.graphite : COLORS.paperLine, background: a.done ? COLORS.graphite : 'transparent' }} aria-label="Mark done" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate" style={{ color: a.done ? COLORS.graphite : COLORS.ink, fontFamily: FONT, fontWeight: 700, textDecoration: a.done ? 'line-through' : 'none' }}>{a.title}</div>
                  {(a.dueTime || durationLabel || a.notes) && (
                    <div className="flex items-center gap-2.5 mt-0.5 flex-wrap">
                      {a.dueTime && (
                        <span className="flex items-center gap-1 text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>
                          <Clock size={11} /> {formatDueTime(a.dueTime)}
                        </span>
                      )}
                      {durationLabel && (
                        <span className="flex items-center gap-1 text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>
                          <Timer size={11} /> ~{durationLabel}
                        </span>
                      )}
                      {a.notes && !a.dueTime && !durationLabel && <span className="text-xs truncate" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>{a.notes}</span>}
                    </div>
                  )}
                </div>
                <span className="text-xs px-2 py-1 rounded-md shrink-0" style={{ fontFamily: FONT, fontWeight: 800, color: status.color, background: `${status.color}18` }}>{status.label}</span>
                {a.source === 'moodle' && <span className="text-xs px-1.5 py-0.5 rounded-md shrink-0" style={{ background: COLORS.pinkSoft, color: COLORS.pinkDeep, fontFamily: FONT, fontWeight: 700 }}>Moodle</span>}
                <button onClick={() => removeItem(a.id)} className="shrink-0 p-1" style={{ color: COLORS.graphite }}><X size={14} /></button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------- Calendar ----------
function CalendarView({ onJumpToPage, notebooks, ready: notebooksReady, assignments, studyBlocks, setStudyBlocks }) {
  const [cursor, setCursor] = useState(new Date());
  const [pagesByNotebook, setPagesByNotebook] = useState({});
  const [personalEvents, setPersonalEvents] = useState([]);
  const [personalIcalUrl, setPersonalIcalUrl] = useState('');
  const [personalPastedICS, setPersonalPastedICS] = useState('');
  const [showPersonalPaste, setShowPersonalPaste] = useState(false);
  const [personalImportStatus, setPersonalImportStatus] = useState(null);
  const [showPersonalLink, setShowPersonalLink] = useState(false);
  const [studyStart, setStudyStart] = useState('16:00');
  const [studyEnd, setStudyEnd] = useState('18:00');
  const [selectedDay, setSelectedDay] = useState(dateKey(new Date()));
  const [pagesReady, setPagesReady] = useState(false);

  useEffect(() => {
    if (!notebooksReady) return;
    (async () => {
      const pe = await storageGet('personal-events', []);
      const url = await storageGet('personal-ical-url', '');
      const pagesMap = {};
      for (const nb of notebooks) {
        pagesMap[nb.id] = await storageGet(`notebook-pages:${nb.id}`, []);
      }
      setPersonalEvents(pe);
      setPersonalIcalUrl(url);
      setPagesByNotebook(pagesMap);
      setPagesReady(true);
    })();
  }, [notebooksReady, notebooks]);

  const mergePersonalEvents = async (events, urlUsed) => {
    setPersonalEvents((prev) => {
      const existingIds = new Set(prev.map((e) => e.id));
      const merged = [...prev, ...events.filter((e) => !existingIds.has(e.id))];
      storageSet('personal-events', merged);
      return merged;
    });
    if (urlUsed) await storageSet('personal-ical-url', personalIcalUrl);
  };

  const importPersonalFromUrl = async () => {
    if (!personalIcalUrl.trim()) return;
    setPersonalImportStatus({ type: 'loading', message: 'Fetching feed…' });
    try {
      const res = await fetch(personalIcalUrl.trim());
      if (!res.ok) throw new Error('bad response');
      const text = await res.text();
      const events = parseICS(text).map((e) => ({ ...e, source: 'personal' }));
      if (events.length === 0) throw new Error('no events found');
      await mergePersonalEvents(events, true);
      setPersonalImportStatus({ type: 'success', message: `Imported ${events.length} event(s) from your calendar.` });
    } catch (e) {
      setPersonalImportStatus({ type: 'error', message: "Couldn't fetch that feed directly (most calendar providers block cross-site requests). Paste the .ics contents below instead." });
      setShowPersonalPaste(true);
    }
  };

  const importPersonalFromPaste = async () => {
    if (!personalPastedICS.trim()) return;
    const events = parseICS(personalPastedICS).map((e) => ({ ...e, source: 'personal' }));
    if (events.length === 0) {
      setPersonalImportStatus({ type: 'error', message: "Couldn't find any events in that text." });
      return;
    }
    await mergePersonalEvents(events, false);
    setPersonalImportStatus({ type: 'success', message: `Imported ${events.length} event(s).` });
    setPersonalPastedICS('');
    setShowPersonalPaste(false);
  };

  const addStudyBlock = async () => {
    if (!studyStart || !studyEnd) return;
    const block = { id: `study-${Date.now()}`, start: studyStart, end: studyEnd };
    const updated = { ...studyBlocks, [selectedDay]: [...(studyBlocks[selectedDay] || []), block] };
    setStudyBlocks(updated);
    await storageSet('study-blocks', updated);
  };

  const removeStudyBlock = async (dayKey, id) => {
    const updated = { ...studyBlocks, [dayKey]: (studyBlocks[dayKey] || []).filter((b) => b.id !== id) };
    setStudyBlocks(updated);
    await storageSet('study-blocks', updated);
  };

  if (!notebooksReady || !pagesReady) return <div className="p-8 text-sm" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Loading calendar…</div>;

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const assignmentsByDay = {};
  assignments.forEach((a) => {
    if (!a.due) return;
    const key = dateKey(a.due);
    (assignmentsByDay[key] = assignmentsByDay[key] || []).push(a);
  });

  const personalByDay = {};
  personalEvents.forEach((e) => {
    if (!e.due) return;
    const key = dateKey(e.due);
    (personalByDay[key] = personalByDay[key] || []).push(e);
  });

  const pagesByDay = {};
  notebooks.forEach((nb) => {
    (pagesByNotebook[nb.id] || []).forEach((p) => {
      const key = dateKey(p.date);
      (pagesByDay[key] = pagesByDay[key] || []).push({ ...p, notebookId: nb.id, notebookTitle: nb.title, notebookColor: nb.color });
    });
  });

  const selectedAssignments = assignmentsByDay[selectedDay] || [];
  const selectedPersonal = personalByDay[selectedDay] || [];
  const selectedPages = pagesByDay[selectedDay] || [];
  const selectedStudyBlocks = studyBlocks[selectedDay] || [];

  return (
    <div className="h-full overflow-y-auto p-6" style={{ background: COLORS.paperTint }}>
      <div className="max-w-3xl mx-auto">
        <div className="mb-4">
          <button onClick={() => setShowPersonalLink((v) => !v)} className="flex items-center gap-1.5 text-xs" style={{ color: COLORS.pinkDeep, fontFamily: FONT, fontWeight: 700 }}>
            <Link2 size={12} /> {showPersonalLink ? 'Hide personal calendar link' : 'Link a personal calendar'}
          </button>
          {showPersonalLink && (
            <div className="mt-2 p-4 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
              <p className="text-xs mb-3" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Paste an iCal (.ics) link from Google Calendar, Apple Calendar, or Outlook to show your personal events here alongside assignments.</p>
              <div className="flex gap-2">
                <input type="text" value={personalIcalUrl} onChange={(e) => setPersonalIcalUrl(e.target.value)} placeholder="https://calendar.google.com/calendar/ical/.../basic.ics" className="flex-1 px-3 py-2 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600, fontSize: '12px' }} />
                <button onClick={importPersonalFromUrl} className="px-3 py-2 rounded-lg text-sm flex items-center gap-1.5 shrink-0" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}><Upload size={14} /> Link</button>
              </div>
              {personalImportStatus && (
                <div className="mt-3 flex items-start gap-2 text-xs px-3 py-2 rounded-lg" style={{ background: personalImportStatus.type === 'error' ? '#FDECEF' : personalImportStatus.type === 'success' ? '#EAF7F3' : '#F7F7FA', color: personalImportStatus.type === 'error' ? COLORS.red : personalImportStatus.type === 'success' ? COLORS.green : COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>
                  <AlertCircle size={14} className="mt-0.5 shrink-0" />
                  <span>{personalImportStatus.message}</span>
                </div>
              )}
              {showPersonalPaste && (
                <div className="mt-3">
                  <textarea value={personalPastedICS} onChange={(e) => setPersonalPastedICS(e.target.value)} placeholder="Paste the full .ics file contents here" rows={4} className="w-full px-3 py-2 text-xs rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
                  <button onClick={importPersonalFromPaste} className="mt-2 px-3 py-1.5 rounded-lg text-xs" style={{ background: COLORS.pink, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>Parse pasted calendar</button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setCursor(new Date(year, month - 1, 1))} className="p-2 rounded-lg" style={{ color: COLORS.pink }}><ChevronLeft size={18} /></button>
          <span className="text-lg" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>{firstDay.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</span>
          <button onClick={() => setCursor(new Date(year, month + 1, 1))} className="p-2 rounded-lg" style={{ color: COLORS.pink }}><ChevronRight size={18} /></button>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-1">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="text-center text-xs py-1" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1 mb-6">
          {cells.map((d, i) => {
            if (d === null) return <div key={i} />;
            const key = dateKey(new Date(year, month, d));
            const dayAssignments = assignmentsByDay[key] || [];
            const dayPersonal = personalByDay[key] || [];
            const dayPages = pagesByDay[key] || [];
            const isSelected = key === selectedDay;
            const isToday = key === dateKey(new Date());
            return (
              <button key={i} onClick={() => setSelectedDay(key)} className="aspect-square rounded-lg p-1 flex flex-col items-start text-left" style={{ background: isSelected ? COLORS.pink : '#FFFFFF', border: isToday ? `2px solid ${COLORS.pink}` : `1px solid ${COLORS.paperLine}` }}>
                <span className="text-xs" style={{ color: isSelected ? '#fff' : COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>{d}</span>
                <div className="flex gap-0.5 flex-wrap mt-auto">
                  {dayAssignments.slice(0, 2).map((a) => <span key={a.id} className="w-1.5 h-1.5 rounded-full" style={{ background: isSelected ? '#fff' : dueStatus(a).color }} />)}
                  {dayPersonal.slice(0, 2).map((e) => <span key={e.id} className="w-1.5 h-1.5 rounded-full" style={{ background: isSelected ? '#fff' : '#5A8DEE' }} />)}
                  {dayPages.slice(0, 2).map((p) => <span key={p.id} className="w-1.5 h-1.5 rounded-sm" style={{ background: isSelected ? '#fff' : p.notebookColor }} />)}
                </div>
              </button>
            );
          })}
        </div>

        <div className="p-4 rounded-xl" style={{ background: '#FFFFFF', border: `1px solid ${COLORS.paperLine}` }}>
          <div className="text-sm mb-3" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink }}>
            {new Date(selectedDay).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
          </div>
          {selectedAssignments.length === 0 && selectedPersonal.length === 0 && selectedPages.length === 0 && selectedStudyBlocks.length === 0 && (
            <p className="text-sm mb-3" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 600 }}>Nothing scheduled this day.</p>
          )}
          {selectedAssignments.length > 0 && (
            <div className="mb-4">
              <div className="text-xs uppercase mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>Assignments</div>
              <div className="space-y-1.5">
                {selectedAssignments.map((a) => {
                  const status = dueStatus(a);
                  const durationLabel = DURATION_OPTIONS.find((d) => d.value === a.duration)?.label;
                  return (
                    <div key={a.id} className="flex items-stretch gap-2.5 rounded-lg overflow-hidden" style={{ background: COLORS.paperTint }}>
                      <div className="shrink-0" style={{ width: 4, background: status.color }} />
                      <div className="flex-1 min-w-0 py-1.5 pr-2">
                        <div className="text-sm" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 700, textDecoration: a.done ? 'line-through' : 'none' }}>{a.title}</div>
                        {(a.dueTime || durationLabel) && (
                          <div className="text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>
                            {a.dueTime ? formatDueTime(a.dueTime) : ''}{a.dueTime && durationLabel ? ' · ' : ''}{durationLabel ? `~${durationLabel}` : ''}
                          </div>
                        )}
                      </div>
                      <span className="text-xs px-1.5 py-0.5 my-1.5 mr-1.5 rounded-md shrink-0 self-start" style={{ fontFamily: FONT, fontWeight: 800, color: status.color, background: `${status.color}18` }}>{status.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          {selectedPersonal.length > 0 && (
            <div className="mb-4">
              <div className="text-xs uppercase mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>Personal calendar</div>
              <div className="space-y-1.5">
                {selectedPersonal.map((e) => (
                  <div key={e.id} className="flex items-stretch gap-2.5 rounded-lg overflow-hidden" style={{ background: COLORS.paperTint }}>
                    <div className="shrink-0" style={{ width: 4, background: '#5A8DEE' }} />
                    <div className="flex-1 min-w-0 py-1.5 pr-2">
                      <div className="text-sm" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>{e.title}</div>
                      <div className="text-xs" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 500 }}>{new Date(e.due).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {selectedStudyBlocks.length > 0 && (
            <div className="mb-4">
              <div className="text-xs uppercase mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>Available study time</div>
              <div className="space-y-1.5">
                {selectedStudyBlocks.map((b) => (
                  <div key={b.id} className="flex items-center gap-2.5 rounded-lg overflow-hidden" style={{ background: COLORS.paperTint }}>
                    <div className="shrink-0" style={{ width: 4, background: COLORS.green, alignSelf: 'stretch' }} />
                    <div className="flex-1 py-1.5 text-sm" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 700 }}>{formatDueTime(b.start)} – {formatDueTime(b.end)}</div>
                    <button onClick={() => removeStudyBlock(selectedDay, b.id)} className="p-1.5 shrink-0" style={{ color: COLORS.graphite }}><X size={13} /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="flex items-center gap-2 mb-4">
            <input type="time" value={studyStart} onChange={(e) => setStudyStart(e.target.value)} className="px-2 py-1.5 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
            <span className="text-xs" style={{ color: COLORS.graphite }}>to</span>
            <input type="time" value={studyEnd} onChange={(e) => setStudyEnd(e.target.value)} className="px-2 py-1.5 text-sm rounded-lg border outline-none" style={{ borderColor: COLORS.paperLine, fontFamily: FONT, fontWeight: 600 }} />
            <button onClick={addStudyBlock} className="px-3 py-1.5 rounded-lg text-xs shrink-0" style={{ background: COLORS.green, color: '#fff', fontFamily: FONT, fontWeight: 700 }}>+ Add study time</button>
          </div>
          {selectedPages.length > 0 && (
            <div>
              <div className="text-xs uppercase mb-1.5" style={{ color: COLORS.graphite, fontFamily: FONT, fontWeight: 800 }}>Notes written</div>
              <div className="space-y-1.5">
                {selectedPages.map((p) => (
                  <button key={p.id} onClick={() => onJumpToPage(p.notebookId, p.id)} className="flex items-center gap-2 text-sm w-full text-left hover:underline" style={{ color: COLORS.ink, fontFamily: FONT, fontWeight: 600 }}>
                    <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: p.notebookColor }} />
                    {p.notebookTitle} — {p.title}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- App shell ----------
export default function App() {
  const [activeTab, setActiveTab] = useState('library');
  const [openNotebookId, setOpenNotebookId] = useState(null);
  const [jumpPageId, setJumpPageId] = useState(null);
  const [notebooks, setNotebooks] = useState([]);
  const [coverPhotos, setCoverPhotos] = useState({});
  const [notebooksReady, setNotebooksReady] = useState(false);
  const [assignments, setAssignments] = useState([]);
  const [assignmentsReady, setAssignmentsReady] = useState(false);
  const [studyBlocks, setStudyBlocks] = useState({});

  useEffect(() => {
    (async () => {
      const savedAssignments = await storageGet('assignments', []);
      const savedStudyBlocks = await storageGet('study-blocks', {});
      setAssignments(savedAssignments);
      setStudyBlocks(savedStudyBlocks);
      setAssignmentsReady(true);
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const saved = await storageGet('notebooks-index', []);
      let list = saved;
      if (saved.length === 0) {
        const sampleId = 'nb-sample';
        const samplePageId = 'page-sample-1';
        const sampleNb = { id: sampleId, title: 'Welcome Notebook', color: '#FFC46B', design: 'arc', createdAt: new Date().toISOString() };
        const samplePage = { id: samplePageId, title: 'Getting Started', pageType: 'ruled', bgColor: '#FFF9EE', date: new Date().toISOString() };
        await storageSet('notebooks-index', [sampleNb]);
        await storageSet(`notebook-pages:${sampleId}`, [samplePage]);
        await storageSet(`note-overlay:${samplePageId}`, [{
          id: 'box-welcome', kind: 'text',
          text: 'Welcome! ✏️\n\nPick up your Pencil and start writing.\nTap + in the Library to make your own notebook.',
          x: 28, y: 28, fontSize: 16, color: COLORS.ink, width: 240,
        }]);
        list = [sampleNb];
      }
      setNotebooks(list);
      const photos = {};
      for (const nb of list) {
        if (nb.hasCoverPhoto) photos[nb.id] = await storageGet(`note-cover:${nb.id}`, null);
      }
      setCoverPhotos(photos);
      setNotebooksReady(true);
    })();
  }, []);

  const handleJumpToPage = (notebookId, pageId) => {
    setOpenNotebookId(notebookId);
    setJumpPageId(pageId);
    setActiveTab('library');
  };

  const tabIcon = { library: BookOpen, planner: CalendarClock, calendar: CalendarIcon };

  return (
    <div className="w-full h-screen flex overflow-hidden" style={{ background: COLORS.paperTint, fontFamily: FONT }}>
      <div className="w-16 shrink-0 flex flex-col items-center py-6 gap-4 border-r" style={{ background: '#FFFFFF', borderColor: COLORS.paperLine }}>
        {NOTEBOOK_TABS.map((tab) => {
          const Icon = tabIcon[tab.id];
          return (
            <button key={tab.id} onClick={() => { setActiveTab(tab.id); if (tab.id !== 'library') setOpenNotebookId(null); }} className="w-11 h-11 rounded-xl flex items-center justify-center transition-transform" style={{ background: activeTab === tab.id ? COLORS.pink : COLORS.pinkSoft, transform: activeTab === tab.id ? 'scale(1.06)' : 'scale(1)' }} title={tab.label}>
              <Icon size={19} color={activeTab === tab.id ? '#fff' : COLORS.pinkDeep} />
            </button>
          );
        })}
      </div>
      <div className="flex-1 flex flex-col min-w-0 m-3 rounded-2xl overflow-hidden shadow-sm" style={{ border: `1px solid ${COLORS.paperLine}` }}>
        {activeTab !== 'library' && (
          <div className="px-5 py-4 flex items-center gap-2 shrink-0" style={{ background: '#FFFFFF', borderBottom: `1px solid ${COLORS.paperLine}` }}>
            <span className="text-lg" style={{ fontFamily: FONT, fontWeight: 800, color: COLORS.ink, letterSpacing: '-0.01em' }}>
              {activeTab === 'planner' ? 'Planner' : 'Calendar'}
            </span>
          </div>
        )}
        <div className="flex-1 min-h-0">
          {activeTab === 'library' && <Library openNotebookId={openNotebookId} setOpenNotebookId={setOpenNotebookId} jumpPageId={jumpPageId} notebooks={notebooks} setNotebooks={setNotebooks} coverPhotos={coverPhotos} setCoverPhotos={setCoverPhotos} ready={notebooksReady} />}
          {activeTab === 'planner' && <Planner assignments={assignments} setAssignments={setAssignments} ready={assignmentsReady} />}
          {activeTab === 'calendar' && <CalendarView onJumpToPage={handleJumpToPage} notebooks={notebooks} ready={notebooksReady} assignments={assignments} studyBlocks={studyBlocks} setStudyBlocks={setStudyBlocks} />}
        </div>
      </div>
    </div>
  );
}
